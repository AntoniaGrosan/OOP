#include "GuiDogs.h"
#include <qboxlayout.h>
#include <qlabel.h>
#include <qline.h>
#include <qlineedit.h>
#include <vector>

//--------------------------------------------- ADMIN ----------------------------------------------------

void GuiAdmin::initGUI()
{
	QHBoxLayout * mainLayout = new QHBoxLayout(this);
	QVBoxLayout * leftLayout = new QVBoxLayout();

	// The dogs in repo: 
	this->listRepo = new QListWidget();
	leftLayout->addWidget(this->listRepo);

	// Boxes for Name, Breed, Age, Link:

	QWidget * detailsWidg = new QWidget;
	QFormLayout * detailsForm = new QFormLayout;
	detailsWidg->setLayout(detailsForm);

	this->breedTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Breed:"), this->breedTxt);

	this->nameTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Name:"), this->nameTxt);

	this->ageTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Age:"), this->ageTxt);

	this->linkTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Photo link:"), this->linkTxt);

	leftLayout->addWidget(detailsWidg);


	//Add, Delete, Update buttons:

	this->addButton = new QPushButton("Add");
	this->addButton->setMinimumWidth(100);

	this->deleteButton = new QPushButton("Delete");
	this->deleteButton->setMinimumWidth(100);

	this->updateButton = new QPushButton("Update");
	this->updateButton->setMinimumWidth(100);

	this->undoButton = new QPushButton("Undo");
	this->undoButton->setMinimumWidth(100);

	this->redoButton = new QPushButton("Redo");
	this->redoButton->setMinimumWidth(100);

	leftLayout->addWidget(addButton);
	leftLayout->addWidget(deleteButton);
	leftLayout->addWidget(updateButton);
	leftLayout->addWidget(undoButton);
	leftLayout->addWidget(redoButton);

	mainLayout->addLayout(leftLayout);
}

void GuiAdmin::addDogInRepo()
{
	try {
		ctrl.addDogToRepo(this->breedTxt->text().toStdString(), this->nameTxt->text().toStdString(), this->ageTxt->text().toInt(), this->linkTxt->text().toStdString());
		reloadRepoList(ctrl.getRepo().getDogsR());
	}
	catch (DogException& ex) {
		std::string message = "";
		for (auto msg : ex.getErrors())
			message = message + " " + msg;
		QMessageBox::warning(this, "Warning", QString::fromStdString(message));
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiAdmin::deleteDogInRepo()
{
	try {
		ctrl.deleteDogFromRepo(this->breedTxt->text().toStdString(), this->nameTxt->text().toStdString());
		reloadRepoList(ctrl.getRepo().getDogsR());
	}
	catch (DogException& ex) {
		std::string message = "";
		for (auto msg : ex.getErrors())
			message = message + " " + msg;
		QMessageBox::warning(this, "Warning", QString::fromStdString(message));
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiAdmin::updateDogInRepo() {
	try {
		ctrl.updateDogFromRepo(this->nameTxt->text().toStdString(), this->breedTxt->text().toStdString(), this->ageTxt->text().toInt(), this->linkTxt->text().toStdString());
		reloadRepoList(ctrl.getRepo().getDogsR());
	}
	catch (DogException& exc) {
		std::string message = "";
		for (auto msg : exc.getErrors())
			message = message + " " + msg;
		QMessageBox::warning(this, "Warning", QString::fromStdString(message));
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiAdmin::undoFunct() {
	try {
		ctrl.undo();
		reloadRepoList(ctrl.getRepo().getDogsR());
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiAdmin::redoFunct() {
	try {
		ctrl.redo();
		reloadRepoList(ctrl.getRepo().getDogsR());
	}
	catch(RepositoryException& exc){
		QMessageBox::warning(this, "Warning!", QString::fromStdString(exc.what()));
	}
}

void GuiAdmin::connectSignalsSlots() {
	QObject::connect(this->listRepo, &QListWidget::itemSelectionChanged, [&]() {
		int pos = listRepo->currentRow();
		Repository rep = ctrl.getRepo();
		Dog d = rep.getDogsR()[pos];
		this->breedTxt->setText(QString::fromStdString(d.getBreed()));
		this->ageTxt->setText(QString::number(d.getAge()));
		this->nameTxt->setText(QString::fromStdString(d.getName()));
		this->linkTxt->setText(QString::fromStdString(d.getLink()));
	});

	QObject::connect(this->addButton, &QPushButton::clicked, this, &GuiAdmin::addDogInRepo);
	QObject::connect(this->deleteButton, &QPushButton::clicked, this, &GuiAdmin::deleteDogInRepo);
	QObject::connect(this->updateButton, &QPushButton::clicked, this, &GuiAdmin::updateDogInRepo);
	QObject::connect(this->undoButton, &QPushButton::clicked, this, &GuiAdmin::undoFunct);
	QObject::connect(this->redoButton, &QPushButton::clicked, this, &GuiAdmin::redoFunct);
}

void GuiAdmin::reloadRepoList(const std::vector<Dog>& dogs) {
	listRepo->clear();
	for (const auto& d : dogs) {
		QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(d.getName()) + ", " + QString::fromStdString(d.getBreed()) + ", " + QString::number(d.getAge()), listRepo);
	}
}

// ----------------------------------------------- ADMIN OR USER? ----------------------------------------


void GuiDogs::initGuiDogs()
{
	QHBoxLayout * mainLayout = new QHBoxLayout(this);
	QVBoxLayout * leftLayout = new QVBoxLayout();
	QVBoxLayout * rightLayout = new QVBoxLayout();

	adminButton = new QPushButton("Admin");
	adminButton->setMinimumWidth(100);

	userButton = new QPushButton("User");
	userButton->setMinimumWidth(100);

	leftLayout->addWidget(adminButton);
	rightLayout->addWidget(userButton);

	mainLayout->addLayout(leftLayout);
	mainLayout->addLayout(rightLayout);
}

void  GuiDogs::openAdminWindow() {
	FileList* l = nullptr;
	Controller ctrl{ repo, l };
	GuiAdmin* gui = new GuiAdmin{ ctrl };
	gui->show();
}

void  GuiDogs::openChooseWindow() {
	GuiChoose* gui = new GuiChoose{ repo };
	gui->show();
}

void  GuiDogs::connectSS()
{
	QObject::connect(this->adminButton, &QPushButton::clicked, this, &GuiDogs::openAdminWindow);
	QObject::connect(this->userButton, &QPushButton::clicked, this, &GuiDogs::openChooseWindow);
}

//------------------------------------------ HTML OR CSV? -------------------------------------------------

void GuiChoose::initGuiChoose()
{
	QHBoxLayout * mainLayout = new QHBoxLayout(this);
	QVBoxLayout * leftLayout = new QVBoxLayout();
	QVBoxLayout * rightLayout = new QVBoxLayout();

	HTMLButton = new QPushButton("HTML");
	HTMLButton->setMinimumWidth(100);

	CSVButton = new QPushButton("CSV");
	CSVButton->setMinimumWidth(100);

	leftLayout->addWidget(HTMLButton);
	rightLayout->addWidget(CSVButton);

	mainLayout->addLayout(leftLayout);
	mainLayout->addLayout(rightLayout);
}

void GuiChoose::connectSSCh()
{
	QObject::connect(this->HTMLButton, &QPushButton::clicked, this, &GuiChoose::createHtmlUserWindow);
	QObject::connect(this->CSVButton, &QPushButton::clicked, this, &GuiChoose::createCsvUserWindow);
}

void GuiChoose::createHtmlUserWindow() {
	FileList* l = new HTMLFile{ "AdoptList.html" };

	Controller ctrl{ repo, l };

	GuiUser* gui = new GuiUser{ ctrl };
	//GuiUser* gui = new GuiUser{ ctrl };
	gui->show();
}

void GuiChoose::createCsvUserWindow() {
	FileList* l = nullptr;
	l = new CSVFile{ "AdoptList.csv" };

	Controller ctrl{ repo, l };

	GuiUser* gui = new GuiUser{ ctrl };
	gui->show();
}

//----------------------------------------  USER  --------------------------------------------------------

void GuiUser::initGuiUser()
{
	QHBoxLayout * mainLayout = new QHBoxLayout(this);
	QVBoxLayout * leftLayout = new QVBoxLayout();
	QVBoxLayout * rightLayout = new QVBoxLayout();

	// The dogs in repo: 
	this->listRepo = new QListWidget();
	leftLayout->addWidget(this->listRepo);

	// Adoption list:
	this->listFilt = new QListWidget();
	rightLayout->addWidget(this->listFilt);

	this->listAdopt = new QListWidget();
	rightLayout->addWidget(this->listAdopt);

	// Boxes for Name, Breed, Age, Link:

	QWidget * detailsWidg = new QWidget;
	QFormLayout * detailsForm = new QFormLayout;
	detailsWidg->setLayout(detailsForm);

	this->breedTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Breed:"), this->breedTxt);

	this->nameTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Name:"), this->nameTxt);

	this->ageTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Age:"), this->ageTxt);

	this->linkTxt = new QLineEdit;
	detailsForm->addRow(new QLabel("Photo link:"), this->linkTxt);

	leftLayout->addWidget(detailsWidg);


	//Add, Filter buttons:

	this->addButton = new QPushButton("Add");
	this->addButton->setMinimumWidth(100);

	this->filterButton = new QPushButton("Filter");
	this->filterButton->setMinimumWidth(100);

	this->undoButton = new QPushButton("Undo");
	this->undoButton->setMinimumWidth(100);

	this->redoButton = new QPushButton("Redo");
	this->redoButton->setMinimumWidth(100);

	leftLayout->addWidget(addButton);
	leftLayout->addWidget(filterButton);
	leftLayout->addWidget(undoButton);
	leftLayout->addWidget(redoButton);

	// Next buttons:

	this->nextButton = new QPushButton("Show dog");
	this->nextButton->setMinimumWidth(100);

	this->viewTableButton = new QPushButton("Table view");
	this->viewTableButton->setMinimumWidth(100);

	rightLayout->addWidget(nextButton);
	rightLayout->addWidget(viewTableButton);

	mainLayout->addLayout(leftLayout);
	mainLayout->addLayout(rightLayout);
}

void GuiUser::addDogToAdoptList()
{
	try {
	Dog* d = new Dog{ this->breedTxt->text().toStdString(), this->nameTxt->text().toStdString(), this->ageTxt->text().toInt(), this->linkTxt->text().toStdString() };
	ctrl.addToAdoptionList(*d);
	ctrl.saveAdoptionList();
	reloadAdoptList(ctrl.getAdoptList()->getDogsAdopt());
	}
	catch (DogException& ex) {
	std::string message = "";
	for (auto msg : ex.getErrors())
	message = message + " " + msg;
	QMessageBox::warning(this, "Warning", QString::fromStdString(message));
	}
	catch (RepositoryException& exc) {
	QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiUser::filterDogsFromRepo()
{
	for (auto d : filtDogs.getDogsR()) {
		filtDogs.deleteDogR(filtDogs.findPosOfDog(d.getName(),d.getBreed()));
	}
	filtDogs = ctrl.filterByBreedAndAge(this->breedTxt->text().toStdString(), this->ageTxt->text().toInt());
	reloadFiltList(filtDogs.getDogsR());
}

void GuiUser::showNext() {
	ctrl.nextDog();
}

void GuiUser::undoFunctAL() {
	try {
		ctrl.undoAdoptList();
		reloadAdoptList(ctrl.getAdoptList()->getDogsAdopt());
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiUser::redoFunctAL() {
	try {
		ctrl.redoAdoptList();
		reloadAdoptList(ctrl.getAdoptList()->getDogsAdopt());
	}
	catch (RepositoryException& exc) {
		QMessageBox::warning(this, "Warning", QString::fromStdString(exc.what()));
	}
}

void GuiUser::connectSignalsSlots()
{
	QObject::connect(this->listRepo, &QListWidget::itemSelectionChanged, [&]() {
		int pos = listRepo->currentRow();
		Repository rep = ctrl.getRepo();
		Dog d = rep.getDogsR()[pos];
		this->breedTxt->setText(QString::fromStdString(d.getBreed()));
		this->ageTxt->setText(QString::number(d.getAge()));
		this->nameTxt->setText(QString::fromStdString(d.getName()));
		this->linkTxt->setText(QString::fromStdString(d.getLink()));
	});

	QObject::connect(this->listFilt, &QListWidget::itemSelectionChanged, [&]() {
		int pos = listFilt->currentRow();
		Dog d = filtDogs.getDogsR()[pos];
		this->breedTxt->setText(QString::fromStdString(d.getBreed()));
		this->ageTxt->setText(QString::number(d.getAge()));
		this->nameTxt->setText(QString::fromStdString(d.getName()));
		this->linkTxt->setText(QString::fromStdString(d.getLink()));
	});

	QObject::connect(this->addButton, &QPushButton::clicked, this, &GuiUser::addDogToAdoptList);
	QObject::connect(this->filterButton, &QPushButton::clicked, this, &GuiUser::filterDogsFromRepo);
	QObject::connect(this->nextButton, &QPushButton::clicked, this, &GuiUser::showNext);
	QObject::connect(this->undoButton, &QPushButton::clicked, this, &GuiUser::undoFunctAL);
	QObject::connect(this->redoButton, &QPushButton::clicked, this, &GuiUser::redoFunctAL);
	QObject::connect(this->viewTableButton, &QPushButton::clicked, this, &GuiUser::ShowTable);

}
void GuiUser::ShowTable() {
	FileList* l = ctrl.getAdoptList();
	AdoptionListModel * model = new AdoptionListModel{ *l };
	AdoptListView* view = new AdoptListView{ model };
	view->show();
}
void GuiUser::reloadRepoList(const std::vector<Dog>& dogs) {
	listRepo->clear();
	for (const auto& d : dogs) {
		QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(d.getName()) + ", " + QString::fromStdString(d.getBreed()) + ", " + QString::number(d.getAge()), listRepo);
		//item->setData(Qt::UserRole, QString::fromStdString(d.getBreed()));
	}
}

void GuiUser::reloadAdoptList(const std::vector<Dog>& dogs) {
	listAdopt->clear();
	for (const auto& d : dogs) {
		QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(d.getName()) + ", " + QString::fromStdString(d.getBreed()) + ", " + QString::number(d.getAge()), listAdopt);
		//item->setData(Qt::UserRole, QString::fromStdString(d.getBreed()));
	}
}

void GuiUser::reloadFiltList(const std::vector<Dog>& dogs) {
	listFilt->clear();
	for (const auto& d : dogs) {
		QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(d.getName()) + ", " + QString::fromStdString(d.getBreed()) + ", " + QString::number(d.getAge()), listFilt);
		//QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(d.getName()), listFilt);
		item->setData(Qt::UserRole, QString::fromStdString(d.getBreed()));
	}
}
