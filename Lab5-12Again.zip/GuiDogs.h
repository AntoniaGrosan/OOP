#pragma once

#include <QListWidget>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QFormLayout>

#include "AdoptListView.h"
#include "Controller.h"
#include "FileList.h"
#include "RepoExceptions.h"

#include <qwidget.h>
#include <qpushbutton.h>
#include <vector>


//---------------------------------------------- ADMIN OR USER? -------------------------------------------
class GuiDogs : public QWidget {
private:
	Repository repo;

	QPushButton * adminButton;
	QPushButton * userButton;

	void initGuiDogs();
	void connectSS();
	void openAdminWindow();
	void openChooseWindow();

public:
	GuiDogs(Repository& _repo) : repo{ _repo } {
		initGuiDogs();
		connectSS();
	}
	~GuiDogs() {}
};

//---------------------------------------------	ADMIN --------------------------------------------------------

class GuiAdmin : public QWidget
{
private:
	std::vector<std::string> elements;

	Controller ctrl;

	QListWidget * listRepo;

	QLineEdit* breedTxt;
	QLineEdit* nameTxt;
	QLineEdit* ageTxt;
	QLineEdit* linkTxt;

	QPushButton * addButton;
	QPushButton * deleteButton;
	QPushButton * updateButton;
	QPushButton * undoButton;
	QPushButton * redoButton;


	void initGUI();
	void addDogInRepo();
	void deleteDogInRepo();
	void updateDogInRepo();
	void undoFunct();
	void redoFunct();

	void connectSignalsSlots();
	void reloadRepoList(const std::vector<Dog>& dogs);

public:
	GuiAdmin(const Controller& contrl) : ctrl{ contrl } {
		initGUI();
		connectSignalsSlots();
		reloadRepoList(contrl.getRepo().getDogsR());
	};
	~GuiAdmin() {}
};

//------------------------------------------- HTML OR CSV? -----------------------------------------------------


class GuiChoose : public QWidget {
private:
	Repository repo;

	QPushButton * CSVButton;
	QPushButton * HTMLButton;

	void initGuiChoose();
	void connectSSCh();
	void createHtmlUserWindow();
	void createCsvUserWindow();

public:
	GuiChoose(Repository& _repo) : repo{ _repo } {
		initGuiChoose();
		connectSSCh();
	}
};

//--------------------------------------------- USER --------------------------------------------------------

class GuiUser : public QWidget {
private:
	std::vector<std::string> elements;

	Controller ctrl;
	Repository filtDogs;

	QListWidget * listRepo;
	QListWidget * listFilt;
	QListWidget * listAdopt;

	QLineEdit* breedTxt;
	QLineEdit* nameTxt;
	QLineEdit* ageTxt;
	QLineEdit* linkTxt;

	QPushButton * addButton;
	QPushButton * filterButton;
	QPushButton * nextButton;
	QPushButton * undoButton;
	QPushButton * redoButton;
	QPushButton * viewTableButton;

	void ShowTable();
	void initGuiUser();
	void addDogToAdoptList();
	void filterDogsFromRepo();
	void showNext();
	void undoFunctAL();
	void redoFunctAL();

	void connectSignalsSlots();
	void reloadRepoList(const std::vector<Dog>& dogs);
	void reloadAdoptList(const std::vector<Dog>& dogs);
	void reloadFiltList(const std::vector<Dog>& dogs);

public:
	GuiUser(const Controller& _ctrl) : ctrl{ _ctrl } {
		initGuiUser();
		connectSignalsSlots();
		reloadRepoList(_ctrl.getRepo().getDogsR());

		FileList * thing = ctrl.getAdoptList();
		reloadAdoptList(thing->getDogsAdopt());

		Repository filtDogs = ctrl.filterByBreedAndAge("", 0);
		reloadFiltList(filtDogs.getDogsR());
	};
	~GuiUser() {}
};
