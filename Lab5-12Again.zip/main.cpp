#include <iostream>
#include <Windows.h>
#include <crtdbg.h>
#include <QtWidgets/QApplication>

#include "GuiDogs.h"
#include "AdoptListView.h"

using namespace std;

int main(int argc, char *argv[]) {

	QApplication a(argc, argv);
	Repository repo{ "Dogs.txt" };

	GuiDogs chooseMenu{ repo };
	chooseMenu.show();

	return a.exec();
}