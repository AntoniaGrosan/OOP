#pragma once
#include <iostream>

//A dog is considered unique by its name and breed.
class Dog {
private:
	std::string breed;
	std::string name;
	int age;
	std::string photoLink;

public:
	Dog();

	Dog(const std::string& breed, const std::string& name, const int& age, const std::string& photoLink);

	std::string getBreed() const { return breed; }
	std::string getName() const { return name; }
	std::string getLink() const { return photoLink; }
	int getAge() const { return age; }

	void setAge(int newAge) { age = newAge; }
	void setLink(std::string newLink) { photoLink = newLink; }

	void showPhoto();

	friend std::istream& operator>>(std::istream& is, Dog& d);
	friend std::ostream& operator<<(std::ostream& os, const Dog& d);
};