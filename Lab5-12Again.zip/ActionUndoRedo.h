#pragma once
#pragma once
#include "Dog.h"
#include "Repository.h"
#include "FileList.h"

class ActionUndoRedo
{
public:
	virtual void executeUndo() = 0;
	virtual void executeRedo() = 0;
	virtual ~ActionUndoRedo() {};
};


class AddUndoRedo : public ActionUndoRedo {
private:
	Dog addedDog;
	Repository& repo; //keep a reference to the repo to be able to exec undo/redo
public:
	AddUndoRedo(const Dog& _addedDog, Repository& _repo) : addedDog{ _addedDog }, repo{ _repo } {};
	
	void executeUndo() override {
		this->repo.deleteDogR(repo.findPosOfDog(addedDog.getName(),addedDog.getBreed()));
	}
	
	void executeRedo() override {
		this->repo.addDogR(addedDog);
	}
};

class DeleteUndoRedo : public ActionUndoRedo {
private:
	Dog deletedDog;
	Repository& repo;
public:
	DeleteUndoRedo(const Dog& _Dog, Repository& _repo) : deletedDog{ _Dog }, repo{ _repo } {};
	
	void executeUndo() override {
		repo.addDogR(deletedDog);
	}

	void executeRedo() override {
		repo.deleteDogR(repo.findPosOfDog(deletedDog.getName(), deletedDog.getBreed()));
	}
};

class UpdateUndoRedo : public ActionUndoRedo {
private:
	Dog updatedDog;
	Dog newDog;
	Repository& repo;
public:
	UpdateUndoRedo(const Dog& _updtDog, const Dog& _newDog, Repository& _repo) : updatedDog{ _updtDog }, newDog{ _newDog }, repo { _repo } {};
	
	void executeUndo() override {
		repo.updateDogR(repo.findPosOfDog(updatedDog.getName(), updatedDog.getBreed()),updatedDog.getLink(),updatedDog.getAge());
	}

	void executeRedo() override {
		repo.updateDogR(repo.findPosOfDog(updatedDog.getName(), updatedDog.getBreed()), newDog.getLink(), newDog.getAge());
	}
};


class AddUndoRedoAdoptList : public ActionUndoRedo {
private:
	Dog addedDog;
	FileList* adoptList;

public:
	AddUndoRedoAdoptList(const Dog& _addedDog, FileList* _adoptList) : addedDog{ _addedDog }, adoptList{ _adoptList } {};

	void executeUndo() override {
		adoptList->Delete(addedDog);
	}

	void executeRedo() override {
		adoptList->Add(addedDog);
	}
};

class DeleteUndoRedoAdoptList : public ActionUndoRedo {
private:
	Dog deletedDog;
	FileList* adoptList;

public:
	DeleteUndoRedoAdoptList(const Dog& _deletedDog, FileList* _adoptList) : deletedDog{ _deletedDog }, adoptList{ _adoptList } {};

	void executeUndo() override {
		adoptList->Add(deletedDog);
	}

	void executeRedo() override {
		adoptList->Delete(deletedDog);
	}
};