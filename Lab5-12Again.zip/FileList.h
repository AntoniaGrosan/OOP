#pragma once
#include "AdoptionList.h"

class FileList : public AdoptionList
{
protected:
	std::string filename;

public:
	FileList(const std::string& filename);
	virtual ~FileList() {};

	virtual void writeToFile() = 0;
	virtual void displayAdoptList() const = 0;

};


class CSVFile : public FileList
{
public:
	CSVFile(const std::string& filename) : FileList{ filename } {}

	void writeToFile() override;
	void displayAdoptList() const override;
};


class HTMLFile : public FileList
{
public:
	HTMLFile(const std::string& filename) : FileList{ filename } {};

	void writeToFile() override;
	void displayAdoptList() const override;
};

