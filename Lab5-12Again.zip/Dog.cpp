#include "Dog.h"
#include <Windows.h>
#include <shellapi.h>
#include "Utils.h"
#include <vector>
#include <iostream>

//deafault constructor:
Dog::Dog() : breed(""), name(""), age(0), photoLink("") {}

Dog::Dog(const std::string & breed, const std::string & name, const int & age, const std::string & photoLink)
{
	this->breed = breed;
	this->name = name;
	this->age = age;
	this->photoLink = photoLink;
}

void Dog::showPhoto() { ShellExecuteA(NULL, NULL, "chrome.exe", this->getLink().c_str(), NULL, SW_SHOWMAXIMIZED); }

std::istream & operator>>(std::istream & is, Dog & d)
{
	std::string line;
	getline(is, line);

	std::vector<std::string> tokens = tokensize(line, ',');

	if (tokens.size() != 4)
		return is;

	d.breed = tokens[0];
	d.name = tokens[1];
	d.age = stod(tokens[2]); //stod = converts s string to double
	d.photoLink = tokens[3];
	return is;
}

std::ostream & operator<<(std::ostream & os, const Dog & d)
{
	os << d.breed << "," << d.name << "," << d.age << "," << d.photoLink;
	return os;
}
