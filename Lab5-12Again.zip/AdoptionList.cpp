#include "AdoptionList.h"

AdoptionList::AdoptionList()
{
	this->current = 0;
}

void AdoptionList::Add(const Dog dog){
	this->dogs.push_back(dog);
}

void AdoptionList::Delete(const Dog dog) {
	int pos = findPosOfDog(dog.getName(), dog.getBreed());
	this->dogs.erase(dogs.begin() + pos);
}

int AdoptionList::findPosOfDog(const std::string & name, const std::string & breed)
{
	if (dogs.size() == 0)
		return -1;

	for (size_t i = 0; i < this->dogs.size(); i++) {
		Dog d = this->dogs[i];
		if (d.getName() == name && d.getBreed() == breed)
			return i;
	}
	return -1;
}

Dog AdoptionList::getCurrentDog()
{
	if (this->current == this->dogs.size())
		this->current = 0;
	return this->dogs[this->current];
	return Dog{};
}

void AdoptionList::show()
{
	if (this->dogs.size() == 0)
		return;
	this->current = 0;
	Dog currentSong = this->getCurrentDog();
	currentSong.showPhoto();
}

void AdoptionList::next()
{
	if (this->dogs.size() == 0)
		return;
	this->current++;
	Dog currentSong = this->getCurrentDog();
	currentSong.showPhoto();
}

bool AdoptionList::isEmpty()
{
	return this->dogs.size() == 0;
}
