#pragma once
#include "Dog.h"
#include "Utils.h"
#include "RepoExceptions.h"
#include <vector>

class Repository {
protected:
	std::vector<Dog> dogs;
	std::string filename;

public:
	Repository() {};
	//Default constructor for the repo
	Repository(const std::string& filename);

	/*
	Adds a dog to the repository.
	Input: d - dog.
	Output: the dog is added to the repository.
	*/
	void addDogR(const Dog& d);

	/*
	Deletes a dog from the repository.
	Input:  pos - the position of the dog which is going to be deleted
	Output: the dog on the position pos is deleted from the repository.
	*/
	void deleteDogR(const int pos);

	/*
	Updates a dog from the repository.
	Input: pos - the position of the dog which is going to be updated.
	newPhotoLink - new photo link(string).
	newAge - new age for the dog(int).
	Output: the dog is deleted from the repository.
	*/
	void updateDogR(const int pos, const std::string newLink, const int newAge);

	/*
	Finds a dog, by name and breed.
	Input: name - the name
	breed - the breed (both string type)
	Output: the dog that was found, or an "empty" dog (all fields empty and age 0), if no dog was found.
	*/
	Dog findByNameAndBreedR(const std::string& name, const std::string& breed);

	/*
	Finds a dog, by name and breed.
	Input: name - the name
	breed - the breed (both string type)
	Output: the position of the dog if it was found or -1 if it was not found
	*/
	int findPosOfDog(const std::string& name, const std::string& breed);

	//Return all the dogs in the repo
	std::vector<Dog> getDogsR() const { return dogs; }

	int getSize() const { return dogs.size(); }

private:
	//Reads the elements of the repo from the file
	void readFromFile();

	//Writes the new content of the repo to the file
	void writeToFile();
};