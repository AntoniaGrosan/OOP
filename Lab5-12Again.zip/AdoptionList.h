#pragma once
#include "Dog.h"
#include "RepoExceptions.h"
#include <vector>

class AdoptionList
{
protected:
	std::vector<Dog> dogs;
	int current;

public:
	AdoptionList();

	std::vector<Dog> getDogsAdopt() const { return dogs; }

	int getSize() const { return dogs.size(); }

	//Adds a dog to the adoption list
	void Add(const Dog dog);

	//Dletes a dog from the adoptin list
	void Delete(const Dog dog);

	int findPosOfDog(const std::string & name, const std::string & breed);

	Dog getCurrentDog();

	//return all dogs from adopt list

	// Shows the first dog from the adoption list.
	void show();

	// Shows the next dog in the adoption list.
	void next();

	// Checks if the adoption list is empty.
	bool isEmpty();

	virtual ~AdoptionList() {}
};

