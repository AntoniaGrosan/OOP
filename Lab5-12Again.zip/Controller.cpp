#include "Controller.h"
#include <algorithm>

void Controller::addDogToRepo(const std::string & breed, const std::string & name, const int & age, const std::string & photoLink)
{
	Dog dog{ breed, name, age, photoLink };
	DogValidator::validateDog(dog);

	int pos = this->repo.findPosOfDog(name, breed);
	this->repo.addDogR(dog);

	ActionUndoRedo* addAct = new AddUndoRedo{ dog,repo };
	undoActions.push_back(addAct);
}

void Controller::deleteDogFromRepo(const std::string & breed, const std::string & name)
{
	Dog dog = this->repo.findByNameAndBreedR(name, breed);
	int pos = this->repo.findPosOfDog(dog.getName(), dog.getBreed());
	this->repo.deleteDogR(pos);

	ActionUndoRedo* delAct = new DeleteUndoRedo{ dog, this->repo };
	undoActions.push_back(delAct);
}

void Controller::updateDogFromRepo(const std::string & name, const std::string & breed, const int newAge, const std::string & newLink)
{
	int pos = this->repo.findPosOfDog(name, breed);
	Dog dog = this->repo.getDogsR()[pos];
	Dog newDog = this->repo.getDogsR()[pos];
	newDog.setAge(newAge);
	newDog.setLink(newLink);
	this->repo.updateDogR(pos, newLink, newAge);

	ActionUndoRedo* updtAct = new UpdateUndoRedo{ dog,newDog,this->repo };
	undoActions.push_back(updtAct);
}

Repository Controller::filterByBreedAndAge(const std::string & breed, const int age)
{
	//Get all dogs:
	std::vector<Dog> dogs = this->repo.getDogsR();

	Repository repoFiltered{ "FilteredDogs.txt" };

	for (size_t i = 0; i < dogs.size(); i++) {
		Dog d = dogs[i];
		if (d.getBreed() == breed && d.getAge() < age)
			repoFiltered.addDogR(d);
	}
	return repoFiltered;
}

void Controller::addToAdoptionList(Dog d)
{
	if (this->adoptList == nullptr)
		return;
	this->adoptList->Add(d);
	ActionUndoRedo* addActAL = new AddUndoRedoAdoptList{ d,this->adoptList };
	undoActionsAdoptList.push_back(addActAL);
}

void Controller::startShowing()
{
	this->adoptList->show();
}

void Controller::nextDog()
{
	this->adoptList->next();
}

void Controller::saveAdoptionList()
{
	if (this->adoptList == nullptr)
		return;

	this->adoptList->writeToFile();
}

void Controller::openAdoptionList() const
{
	this->adoptList->displayAdoptList();
}

void Controller::undo() {
	if (this->undoActions.empty())
		throw RepositoryException("No operation to undo!");

	undoActions.back()->executeUndo();
	redoActions.push_back(undoActions.back());
	undoActions.pop_back();
}

void Controller::redo() {
	if (this->redoActions.empty())
		throw RepositoryException("No operation to redo!");

	redoActions.back()->executeRedo();
	undoActions.push_back(redoActions.back());
	redoActions.pop_back();
}

void Controller::undoAdoptList() {
	if (this->undoActionsAdoptList.empty())
		throw RepositoryException("No operation to undo!");

	undoActionsAdoptList.back()->executeUndo();
	redoActionsAdoptList.push_back(undoActionsAdoptList.back());
	undoActionsAdoptList.pop_back();
}

void Controller::redoAdoptList() {
	if (this->redoActionsAdoptList.empty())
		throw RepositoryException("No operation to redo!");

	redoActionsAdoptList.back()->executeRedo();
	undoActionsAdoptList.push_back(redoActionsAdoptList.back());
	redoActionsAdoptList.pop_back();
}
