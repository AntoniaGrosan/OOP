#include "AdoptionListModel.h"

int AdoptionListModel::rowCount(const QModelIndex & parent) const{
	return this->adoptList.getSize();
}

int AdoptionListModel::columnCount(const QModelIndex & parent) const{
	return 4;
}

QVariant AdoptionListModel::data(const QModelIndex & index, int role) const
{
	int row = index.row();
	int col = index.column();

	Dog dog = this->adoptList.getDogsAdopt()[row];

	if (role == Qt::DisplayRole)
	{
		switch (col)
		{
		case 0:
			return QString::fromStdString(dog.getBreed());
			break;
		case 1:
			return QString::fromStdString(dog.getName());
			break;
		case 2:
			return QString::fromStdString(std::to_string(dog.getAge()));
			break;
		/*
		case 3:
			return QString::fromStdString(dog.getLink());
			break;*/
		}
	}

	return QVariant();
}

QVariant AdoptionListModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal)
		{
			switch (section)
			{
			case 0:
				return tr("Breed");

			case 1:
				return tr("Name");

			case 2:
				return tr("Age");

			case 3:
				return tr("Photo link");

			default:
				return QVariant();
			}
		}
	}
	return QVariant();
}

