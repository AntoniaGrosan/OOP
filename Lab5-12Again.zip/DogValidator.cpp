#include "DogValidator.h"

void DogValidator::validateDog(const Dog & doggo)
{
	std::vector<std::string> errors;

	if (doggo.getName().size() <= 1)
		errors.push_back("Invalid name!");

	if (doggo.getBreed().size() <= 2)
		errors.push_back("Invalid breed!");

	if (doggo.getAge() == 0)
		errors.push_back("Dog not born yet!");

	if (doggo.getLink().size() <= 10)
		errors.push_back("Invalid link!");

	if (errors.size() > 0)
		throw DogException(errors);
}
