#pragma once
#include "AdoptionListModel.h"
#include "AdoptListView.h"
#include <qabstractitemmodel.h>
#include <QWidget>
#include "ui_AdoptListView.h"

class AdoptListView : public QWidget
{
	Q_OBJECT

public:
	AdoptListView(QAbstractItemModel * model, QWidget *parent = Q_NULLPTR);
	~AdoptListView() {};

private:
	Ui::AdoptListView ui;
	AdoptionListModel * alModel;
};
