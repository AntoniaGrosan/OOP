#include "AdoptListView.h"
#include "PictureDelegate.h"

AdoptListView::AdoptListView(QAbstractItemModel * model, QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	ui.adoptListTableView->setModel(model);
	ui.adoptListTableView->setItemDelegate(new PictureDelegate{});
}

