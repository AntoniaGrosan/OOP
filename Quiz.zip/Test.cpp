#include "Test.h"
#include "Repository.h"
#include "Subject.h"
#include "Domain.h"
#include "ParticipantWindow.h"
#include "PresenterWindow.h"
#include <assert.h>
#include <string.h>

void Test::test()
{
	Repository repo("Questions.txt", "Participants.txt");
	assert(repo.getParticipants().size() == 3);
	assert(repo.getQuestions().size() == 2);
	Question q{ "4","Hello","world",10 };
	bool ok = true;
	try {
		repo.add_question(q);
	}
	catch (exception& e)
	{
		ok = false;
	}
	assert(ok = true);
	assert(repo.getQuestions().size() == 3);
}