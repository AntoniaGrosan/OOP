#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Quiz2.h"

class Quiz2 : public QMainWindow
{
	Q_OBJECT

public:
	Quiz2(QWidget *parent = Q_NULLPTR);

private:
	Ui::Quiz2Class ui;
};
