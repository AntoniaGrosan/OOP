#include "ParticipantWindow.h"
#include <qmessagebox>

ParticipantWindow::ParticipantWindow(Contest &contest, Participant &participant, QWidget *parent)
	: contest{ contest }, participant{ participant }, QWidget(parent){
	ui.setupUi(this);
	
	QObject::connect(ui.Answer, &QPushButton::clicked, this, &ParticipantWindow::answerHandler);
	
	QWidget::setWindowTitle(QString::fromStdString(this->participant.get_name()));
	this->update();
}

ParticipantWindow::~ParticipantWindow() {}

void ParticipantWindow::update()
{
	this->questions = this->contest.get_questions();
	std::sort(this->questions.begin(), this->questions.end(), [](Question &q1, Question &q2) {return q1.get_score() > q2.get_score(); });
	this->populate_list();
}

void ParticipantWindow::populate_list()
{
	auto questions = this->questions;
	ui.questions_list->clear();
	for (auto q : questions)
	{
		QString item = QString::fromStdString(q.to_string());
		QListWidgetItem* it = new QListWidgetItem{ item };
		QColor color{ "green" };
		QBrush brush{ color };
		for (auto ques : answered)
			if (ques.get_id() == q.get_id())
				it->setForeground(color);
		ui.questions_list->addItem(it);
	}
}

void ParticipantWindow::answerHandler()
{
	QListWidgetItem* item = ui.questions_list->currentItem();
	QColor color{ "green" };
	QBrush brush{ color };

	if (item->foreground() == brush)
		QMessageBox::warning(this, "Warning", QString("Question already answered!"));
	else
	{
		int row = ui.questions_list->currentRow();
		Question q = questions[row];

		QString Qanswer = ui.answer_text_edit->toPlainText();
		std::string answer = Qanswer.toStdString();

		if (answer == q.get_answer())
		{
			item->setForeground(brush);
			this->contest.update_score_of_participant(participant,q.get_score());
			ui.score_label->setText(QString::number(this->participant.get_score()));
			answered.push_back(q);
		}
		else
			QMessageBox::warning(this, "Warning", QString("Incorect Answer!"));
	}
}

