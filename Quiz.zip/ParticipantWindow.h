#pragma once

#include <QWidget>
#include "ui_ParticipantWindow.h"
//#include "Observer.h"
#include "Domain.h"
#include "Subject.h"

class ParticipantWindow : public QWidget, public Observer
{
	Q_OBJECT

public:
	ParticipantWindow(const ParticipantWindow& pw);
	ParticipantWindow(Contest &contest, Participant &participant, QWidget *parent = Q_NULLPTR);
	~ParticipantWindow();
	void update() override;
	void populate_list();

	void answerHandler();

private:
	Ui::ParticipantWindow ui;
	Contest &contest;
	Participant &participant;
	std::vector<Question> questions;
	std::vector<Question> answered;
};
