#include "Quiz2.h"

Quiz2::Quiz2(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
