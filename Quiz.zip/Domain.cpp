#include "Domain.h"

std::string Question::to_string()
{
	std::string score_std = std::to_string(score);
	return id + " - " + text + " - " + score_std;
}

void Participant::increase_score(int score)
{
	this->score += score;
}

ostream & operator<<(ostream & os, Question q)
{
	os << q.get_id() << ',' << q.get_text() << ',' << q.get_answer() << ',' << q.get_score();
	return os;
}
