#include "Repository.h"
#include <fstream>
#include <string>
#include <istream>
#include <sstream>
#include <vector>

void Repository::read_questions()
{
	std::ifstream f(questions_filename);

	if (!f.is_open())
		return;

	std::string line;
	while (getline(f, line))
	{
		std::vector<std::string> result;
		std::stringstream ss(line);
		std::string token;
		while (getline(ss, token, ','))
			result.push_back(token);
		if (result.size() == 4)
		{
			int score = stoi(result[3]);
			Question question(result[0], result[1], result[2], score);
			this->questions.push_back(question);
		}
	}
}

void Repository::read_participants()
{
	std::ifstream f(participants_filename);

	std::string line;
	while (getline(f, line))
	{
		std::vector<std::string> result;
		std::stringstream ss(line);
		std::string token;
		while (getline(ss, token, ','))
			result.push_back(token);
		if (result.size() == 2)
		{
			int score = stoi(result[1]);
			Participant participant(result[0], score);
			this->participants.push_back(participant);
		}
	}
}

void Repository::write_questions()
{
	ofstream f(this->questions_filename);

	for (auto q : this->questions)
		f << q <<endl;
}

Repository::Repository(std::string q_filename, std::string p_filename) : questions_filename{ q_filename }, participants_filename{ p_filename }
{
	this->read_questions();
	this->read_participants();
}
/*
Adds the given question in the repo
input: question - the question which will be added
output: -
*/
void Repository::add_question(Question question)
{
	if (question.get_text() == "")
		throw(std::exception("Question must not hve empty text!"));
	for (int i = 0; i < questions.size(); i++)
		if (questions[i].get_id() == question.get_id())
			throw(std::exception("Question already exists!"));
	this->questions.push_back(question);
	this->write_questions();
}
/*
Increases the score of a participant with a score
input: p - the participant which will have the score increased
		score the number to be added to the score of the participant
output: -
*/
void Repository::update_score(Participant p, int score){
	for (auto part : this->participants)
		if (part.get_name() == p.get_name())
			part.increase_score(score);
}
