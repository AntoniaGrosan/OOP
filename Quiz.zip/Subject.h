#pragma once
#include <vector>
#include "Repository.h"
//#include "observer.h"

class Observer
{
public:
	virtual void update() = 0;
};
class Subject
{
private:
	std::vector<Observer*> observers;

public:
	void register_observer(Observer* observer);
	void notify();
};

class Contest : public Subject
{
private:
	Repository & repo;

public:
	Contest(Repository &repo) : repo{ repo } {};

	//Desc: send a question to the repository to be addded and notifies the observers for update
	//Pre: question is an instance of the class Question
	//Post: question was added and observers notified
	void add_question(Question question);
	void update_score_of_participant(Participant p, int score);
	std::vector<Question> get_questions();
};