#include "PresenterWindow.h"
#include <qmessagebox.h>
using namespace std;
PresenterWindow::PresenterWindow(Contest &contest, QWidget *parent) : contest{ contest }, QWidget(parent) {
	ui.setupUi(this);
	
	QObject::connect(ui.add_question_button, &QPushButton::clicked, this, &PresenterWindow::add_question_handler);
	
	QWidget::setWindowTitle(QString::fromStdString("Presenter"));
	this->update();
}

PresenterWindow::~PresenterWindow() {}

void PresenterWindow::update()
{
	this->populate_list();
}

void PresenterWindow::populate_list()
{
	this->questions = this->contest.get_questions();
	sort(this->questions.begin(), this->questions.end(), [](Question &q1, Question &q2) {return q1.get_score() < q2.get_score(); });
	auto questions = this->questions;
	ui.questions_list->clear();
	for (auto q : questions)
	{
		QString item = QString::fromStdString(q.get_id()) + " - " + QString::fromStdString(q.get_text()) + " - "+ QString::fromStdString(q.get_answer()) + " - " +QString::number(q.get_score());

		ui.questions_list->addItem(item);
	}
}

void PresenterWindow::add_question_handler()
{
	string id = ui.id_line_edit->text().toStdString();
	string text = ui.text_line_edit->text().toStdString();
	string answer = ui._answer_line_edit->text().toStdString();
	int score = ui.score_line_edit->text().toInt();

	Question q{ id, text, answer, score };
	try {
		this->contest.add_question(q);
	}
	catch (exception &exc)
	{
		QMessageBox::warning(this, "Warning", exc.what());
	}
}
