#pragma once
#include <vector>
#include "Domain.h"
#include <string>

class Repository
{
private:
	std::vector<Question> questions;
	std::vector<Participant> participants;
	std::string questions_filename;
	std::string participants_filename;

	void read_questions();
	void read_participants();
	void write_questions();

public:
	Repository(std::string q_filename, std::string p_filename);
	void add_question(Question question);
	void update_score(Participant p, int score);
	std::vector<Question> getQuestions() const { return this->questions; }
	std::vector<Participant> &getParticipants() { return this->participants; }
	~Repository() {};
};