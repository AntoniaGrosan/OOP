#include "Subject.h"

void Subject::register_observer(Observer* observer)
{
	this->observers.push_back(observer);
}

void Subject::notify()
{
	for (auto ob : observers)
		ob->update();
}

void Contest::add_question(Question question)
{
	repo.add_question(question);
	this->notify();
}

void Contest::update_score_of_participant(Participant p, int score){
	repo.update_score(p, score);
	this->notify();
}

std::vector<Question> Contest::get_questions()
{
	return this->repo.getQuestions();
}
