#pragma once
#include <qwidget.h>

class Observer
{
public:
	virtual void update() = 0;
};