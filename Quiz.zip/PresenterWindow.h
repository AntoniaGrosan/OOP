#pragma once

#include <QWidget>
#include "ui_PresenterWindow.h"
//#include "Observer.h"
#include "Domain.h"
#include "Subject.h"

class PresenterWindow : public QWidget, public Observer
{
	Q_OBJECT

public:
	PresenterWindow(Contest &contest, QWidget *parent = Q_NULLPTR);
	~PresenterWindow();

	void update() override;
	void populate_list();
	void add_question_handler();

private:
	Ui::PresenterWindow ui;
	Contest &contest;
	std::vector<Question> questions;
};
