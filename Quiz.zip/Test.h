#pragma once

class Test
{
public:
	static void test();
};