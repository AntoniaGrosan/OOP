#pragma once
#include <string>
#include <iostream>
using namespace std;
class Question
{
private:
	std::string id;
	std::string text;
	std::string answer;
	int score;
public:
	Question(std::string id, std::string text, std::string answer, int score) : id{ id }, text{ text }, answer{ answer }, score{ score } {};
	std::string to_string();
	std::string get_answer() const { return this->answer; }
	std::string get_id() const { return this->id; }
	int get_score() const { return this->score; }
	std::string get_text() const { return this->text; }
	~Question() {};
	friend ostream& operator<<(ostream& os, Question q);
};

class Participant
{
private:
	std::string name;
	int score;

public:
	Participant(std::string name, int score) : name{ name }, score{ score } {};
	~Participant() {};
	void increase_score(int score);
	std::string get_name() { return this->name; }
	int get_score() const { return this->score; }
};