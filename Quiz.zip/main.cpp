#include <QtWidgets/QApplication>
#include "Repository.h"
#include "Subject.h"
#include "Domain.h"
#include "ParticipantWindow.h"
#include "PresenterWindow.h"
#include "Test.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	Test::test();

	Repository repo("Questions.txt", "Participants.txt");
	auto q = repo.getQuestions();
	auto participants = repo.getParticipants();

	Contest contest{ repo };

	std::vector<ParticipantWindow*> participantsW;
	for (int i = 0; i < participants.size(); i++) {
		ParticipantWindow* w = new ParticipantWindow{ contest,participants[i] };
		participantsW.push_back(w);
	}
	for (int i = 0; i < participants.size(); i++)
	{
		contest.register_observer(participantsW[i]);
		(*participantsW[i]).show();
	}

	PresenterWindow* presenter = new PresenterWindow{ contest };
	contest.register_observer(presenter);
	presenter->show();
	return a.exec();
}
