#pragma once
#include "Repository.h"
#include "FileList.h"
#include "DogValidator.h"

class Controller
{
private:
	Repository repo;
	FileList* adoptList;

public:
	//Default constructer of the controller class
	Controller(Repository& r, FileList* l) : repo{ r }, adoptList{ l } {}

	Repository getRepo() const { return repo; }
	FileList* getAdoptList() const { return adoptList; }

	/*
	Add a dog to the repo of dogs if possible
	Input: name - the name of dog which we want to add
		   breed - the breed of dog which we want to add
		   age - the age of the dog
		   link - the photo link of the dog
	Output: True - the dog can be added
			False - the dog can't be added, as another dog with the same name and breed already exists
	*/
	void addDogToRepo(const std::string & breed, const std::string & name, const int & age, const std::string & photoLink);

	/*
	Delete a dog from the repo of dogs if possible
	Input: name - the name of the dog which we want to delete
		   breed - the breed of the dog which we want to delete
	Output: True - the dog could be deleted
			False - the dog can't be deleted, as no dog with the same name and breed exists
	*/
	void deleteDogFromRepo(const std::string & breed, const std::string & name);

	/*
	Update a dog from the repo of dogs if possible
	Input: name - the name of dog which we want to update
		   breed - the breed of dog which we want to update
		   newAge - the new age of the dog
		   newLink - the new link of the dog
	Output: True - the dog can be added
	False - the dog can't be added, as another dog with the same name and breed
	*/
	void updateDogFromRepo(const std::string& name, const std::string& breed,const int newAge, const std::string& newLink);

	/*
	Filters a repo of dogs by breed and age
	Input: breed - the breed which we are looking for
		   age - the dogs mus have the age less than this
	Output: A repository containing the dogs which respect the criterias of the filter
	*/
	Repository filterByBreedAndAge(const std::string& breed, const int age);

	/*
	Add a dog to the adoption list if possible
	Input: the dog we want to add to the list
	Output: the dog is added
	*/
	void addToAdoptionList(Dog d);

	void startShowing();

	void nextDog();

	/*
	Saves the adoptionlist.
	Throws: FileException - if the given file cannot be opened.
	*/
	void saveAdoptionList();

	/*
	Opens the AdoptionList, with an appropriate application.
	Throws: FileException - if the given file cannot be opened.
	*/
	void openAdoptionList() const;
};
