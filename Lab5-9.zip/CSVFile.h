#pragma once
#include "FileList.h"

class CSVFile : public FileList
{
public:
	CSVFile(const std::string& filename) : FileList{ filename } {}

	void writeToFile() override;
	void displayAdoptList() const override;
};

