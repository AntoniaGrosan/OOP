#include "Tests.h"
#include "UI.h"
#include <iostream>
#include <Windows.h>
#include <crtdbg.h>
#include "RepoExceptions.h"
#include "CSVFile.h"
#include "HTMLFile.h"

using namespace std;

int main() {
{
	//Tests::TestAll();

	try
	{
		Repository Repo("Dogs.txt");
		cout << "1 - CSV mode." << endl;
		cout << "2 - HTML mode." << endl;
		int cmdAdL = 0;
		cin >> cmdAdL;
		cin.ignore();
		cout << endl;
		FileList* l = nullptr;
		bool ok = true;
		while (ok) {
			if (cmdAdL == 1) {
				l = new CSVFile{ "AdoptList.csv" };
				ok = false;
			}
			else if (cmdAdL == 2) {
				l = new HTMLFile{ "AdoptList.html" };
				ok = false;
			}
			else 
				cout << "Enter 1 or 2!" << endl;
		}
		Controller Ctrl( Repo,l );
		UI UserInterf{ Ctrl };

		UserInterf.run();
		delete l;
	}
	catch (FileException&)
	{
		cout << "Repository file could not be opened! The application will terminate." << endl;
		return 1;
	}

}
	_CrtDumpMemoryLeaks();
	system("pause");
	return 0;
}