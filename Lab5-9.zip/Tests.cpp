#include <assert.h>
#include "Tests.h"
#include "Dog.h"
#include "DogValidator.h"
#include "Repository.h"
#include "Controller.h"
#include "AdoptionList.h"
#include "CSVFile.h"

void Tests::TestDog(){
	Dog d{ "husky", "Happy", 2, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg" };
	assert(d.getBreed() == "husky");
	assert(d.getName() == "Happy");
	assert(d.getAge() == 2);
	assert(d.getLink() == "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg");
	
	d.showPhoto();
	d.setAge(5);
	assert(d.getAge() == 5);
	d.setLink("http://www.redlandlabradors.com/Sioux2.JPG");
	assert(d.getLink() == "http://www.redlandlabradors.com/Sioux2.JPG");
	
	Dog d2{};
	assert(d2.getBreed() == "");
	assert(d2.getName() == "");
	assert(d2.getAge() == 0);
	assert(d2.getLink() == "");
	
}

void Tests::TestDogException()
{
	int ok = 0;
	Dog d{ "p", "", 0, "https://img.buzzfeed.com/buzzfeed-static/static/2016-11/2/13/asset/buzzfeed-prod-web08/sub-buzz-11149-1478107381-1.png?downsize=715:*&output-format=auto&output-quality=auto" };
	try
	{
		DogValidator::validateDog(d);
	}
	catch (DogException& exc)
	{
		ok = exc.getErrors().size();
	}
	assert(ok == 3);
}


void Tests::TestRepo() {
	Repository repo{"test_repo.txt"};
	Dog d1{ "husky", "Happy", 2, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg" };
	Dog d2{ "labrador", "Toby", 5, "http://www.redlandlabradors.com/Sioux2.JPG" };
	Dog d3{ "beagle", "Bijou", 1, "https://vetstreet-brightspot.s3.amazonaws.com/75/371580ca7a11e0ad9e12313817c323/file/Beagle-1-645mk062311.jpg" };
	
	Dog dog1 = repo.findByNameAndBreedR("Toby", "labrador");
	assert(dog1.getAge() == 0 && dog1.getBreed() == "");

	repo.addDogR(d1);
	repo.addDogR(d2);
	repo.addDogR(d3);

	int pos = repo.findPosOfDog("Happy", "husky");
	assert(pos == 0);

	pos = repo.findPosOfDog("Toby", "labrador");
	assert(pos == 1);

	repo.deleteDogR(0);

	std::vector<Dog> dogs = repo.getDogsR();
	assert(dogs.size() == 2);

	Dog dog2 = repo.findByNameAndBreedR("Toby", "labrador");
	assert(dog2.getBreed() == "labrador" && dog2.getAge() == 5);

	repo.updateDogR(1, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg", 2);
	Dog dog3 = repo.findByNameAndBreedR("Bijou", "beagle");
	assert(dog3.getAge() == 2);
}

void Tests::TestController() {
	Repository repo{"test_ctrl.txt"};
	FileList* l = new CSVFile{"AdoptList.csv"};
	Controller ctrl{ repo,l };
	
	ctrl.addDogToRepo("husky", "Happy", 2, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg");

	ctrl.addDogToRepo("labrador", "Toby", 5, "http://www.redlandlabradors.com/Sioux2.JPG");
	
	ctrl.addDogToRepo("husky", "Happy", 2, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg");

	ctrl.addDogToRepo("beagle", "Bijou", 1, "https://vetstreet-brightspot.s3.amazonaws.com/75/371580ca7a11e0ad9e12313817c323/file/Beagle-1-645mk062311.jpg");
	assert(ctrl.getRepo().getDogsR().size() == 3);

	ctrl.deleteDogFromRepo("beagle", "Bijou");

	assert(ctrl.getRepo().getDogsR().size() == 2);

	ctrl.deleteDogFromRepo("beagle", "Bijou");

	ctrl.addDogToRepo("yorkshire terrier", "Ben", 3, "http://6004-presscdn-27-34.pagely.netdna-cdn.com/wp-content/uploads/2016/09/shWRW3E-730x430.jpg");
	ctrl.updateDogFromRepo( "Ben", "yorkshire terrier", 7, "http://www.redlandlabradors.com/Sioux2.JPG");

	ctrl.updateDogFromRepo("Bob", "dalmatian", 7, "http://www.redlandlabradors.com/Sioux2.JPG");

	ctrl.addDogToRepo("beagle", "Bobby", 2, "https://vetstreet-brightspot.s3.amazonaws.com/75/371580ca7a11e0ad9e12313817c323/file/Beagle-1-645mk062311.jpg");
	ctrl.addDogToRepo("beagle", "Sunny", 4, "https://vetstreet-brightspot.s3.amazonaws.com/75/371580ca7a11e0ad9e12313817c323/file/Beagle-1-645mk062311.jpg");

	Repository repoFilt = ctrl.filterByBreedAndAge("beagle", 5);
	assert(repoFilt.getSize() == 2);

	FileList* AL = ctrl.getAdoptList();
	assert(AL->isEmpty() == true);

	Dog d1{ "beagle", "Sunny", 4, "https://vetstreet-brightspot.s3.amazonaws.com/75/371580ca7a11e0ad9e12313817c323/file/Beagle-1-645mk062311.jpg"};
	ctrl.addToAdoptionList(d1);
	FileList* AL1 = ctrl.getAdoptList();
	assert(AL1->isEmpty() == false);

	Dog d2{ "yorkshire terrier", "Ben", 3, "http://6004-presscdn-27-34.pagely.netdna-cdn.com/wp-content/uploads/2016/09/shWRW3E-730x430.jpg" };
	ctrl.addToAdoptionList(d2);

	ctrl.startShowing();
	ctrl.nextDog();
}

void Tests::TestAdoptionList()
{
	AdoptionList adoptL{};
	assert(adoptL.isEmpty() == true);

	//this 2 shouldn't do anything:  
	adoptL.next();
	adoptL.show();

	Dog d = adoptL.getCurrentDog();
	assert(d.getBreed() == "" && d.getAge() == 0);

	Dog d1{ "husky", "Happy", 2, "https://i.pinimg.com/originals/ae/07/e1/ae07e1093c2d01aab8c44cfe49504f69.jpg" };
	adoptL.Add(d1);

	assert(adoptL.isEmpty() == false);

	Dog d3{ "labrador", "Toby", 5, "http://www.redlandlabradors.com/Sioux2.JPG" };
	adoptL.Add(d3);

	Dog d2 = adoptL.getCurrentDog();
	assert(d1.getBreed() == d2.getBreed() && d1.getAge() == d2.getAge() && d1.getName() == d2.getName() && d1.getLink() == d2.getLink());

	adoptL.next();
	adoptL.show();
}

void Tests::TestAll() {
	TestDog();
	//TestRepo();
	//TestController();
	//TestAdoptionList();
}