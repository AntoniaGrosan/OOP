#include "HTMLFile.h"
#include <fstream>
#include <Windows.h>
#include "RepoExceptions.h"

using namespace std;

void HTMLFile::writeToFile()
{
	ofstream f(this->filename);

	if (!f.is_open())
		throw FileException("The file could not be opened!");

	f << "<!DOCTYPE html>" << endl << "<html>" << endl << "<head>" << endl << "<title>" << this->filename << "</title>" << endl << "</head>" << endl << "<body>" << endl << "<table border=\"1\">" << endl;
	f << "<td>" << "Breed" << "</td>" << endl << "<td>" << "Name" << "</td>" << endl << "<td>" << "Age" << "</td>" << endl << "<td>" << "Photo Link" << "</td>" << endl;
	
	for (auto d : this->dogs) {
		f << "<tr>" << endl;
		f << "<td>" << d.getBreed() << "</td>" << endl << "<td>" << d.getName() << "</td>" << endl << "<td>" << d.getAge() << "</td>" << endl << "<td>" << d.getLink() << "</td>" << endl;
		f << "</tr>" << endl;
	}
	f << "</table>" << endl << "</body>" << endl << "</html>";
	f.close();
}

void HTMLFile::displayAdoptList() const
{
	string aux = "\"" + this->filename + "\"";
	//string aux = this->filename;
	ShellExecuteA(NULL, NULL, "chrome.exe", aux.c_str(), NULL, SW_SHOWMAXIMIZED);
}
