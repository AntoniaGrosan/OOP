#pragma once
#include <vector>
#include "Dog.h"

class DogException 
{
private:
	std::vector<std::string> errors;
public:
	DogException(std::vector<std::string>& vectOfErrors) { errors = vectOfErrors; }
	std::vector<std::string> getErrors() { return errors; }
};

class DogValidator
{
public:
	static void validateDog(const Dog& doggo);
};

