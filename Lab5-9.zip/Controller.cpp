#include "Controller.h"
#include <algorithm>
#include "FileList.h"

void Controller::addDogToRepo(const std::string & breed, const std::string & name, const int & age, const std::string & photoLink)
{
	Dog dog{ breed, name, age, photoLink };
	DogValidator::validateDog(dog);

	int pos = this->repo.findPosOfDog(name, breed);
	this->repo.addDogR(dog);
}

void Controller::deleteDogFromRepo(const std::string & breed, const std::string & name)
{
	Dog dog = this->repo.findByNameAndBreedR(name, breed);
	int pos = this->repo.findPosOfDog(dog.getName(),dog.getBreed());
	this->repo.deleteDogR(pos);
}

void Controller::updateDogFromRepo(const std::string & name, const std::string & breed, const int newAge, const std::string & newLink)
{
	int pos = this->repo.findPosOfDog(name, breed);
    this->repo.updateDogR(pos, newLink, newAge);
}

Repository Controller::filterByBreedAndAge(const std::string & breed, const int age)
{
	//get all songs:
	std::vector<Dog> dogs = this->repo.getDogsR();

	Repository repoFiltered{"FilteredDogs.txt"};

	for (size_t i = 0; i < dogs.size(); i++) {
		Dog d = dogs[i];
		if (d.getBreed() == breed && d.getAge() < age)
			repoFiltered.addDogR(d);
	}
	return repoFiltered;
}

void Controller::addToAdoptionList(Dog d)
{
	if (this->adoptList == nullptr)
		return;
	this->adoptList->Add(d);
}

void Controller::startShowing()
{
	this->adoptList->show();
}

void Controller::nextDog()
{
	this->adoptList->next();
}

void Controller::saveAdoptionList()
{
	if (this->adoptList == nullptr)
		return;

	this->adoptList->writeToFile();
}

void Controller::openAdoptionList() const
{
	//if (this->adoptList == nullptr)
		//return;

	this->adoptList->displayAdoptList();
}
