#include "FileList.h"

FileList::FileList(const std::string & filename)
{
	this->filename = filename;
}
