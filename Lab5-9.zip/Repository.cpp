#include "Repository.h"
#include <string>
#include <fstream>
#include "Utils.h"
#include "RepoExceptions.h"

using namespace std;

Repository::Repository(const std::string& filename) {
	this->filename = filename;
	this->readFromFile();
}

void Repository::addDogR(const Dog & d){
	if (this->findByNameAndBreedR(d.getName(),d.getBreed()).getName() != "")
		throw DuplicateDogException();
	this->dogs.push_back(d);
	this->writeToFile();
}

void Repository::deleteDogR(const int pos)
{
	if (pos == -1) 
		throw NoExistingDogException();
	this->dogs.erase(dogs.begin() + pos);
	this->writeToFile();
}

void Repository::updateDogR(const int pos, const std::string newLink, const int newAge)
{
	if (pos == -1)
		throw NoExistingDogException();
	this->dogs[pos].setLink(newLink);
	this->dogs[pos].setAge(newAge);
}

Dog Repository::findByNameAndBreedR(const std::string & name, const std::string & breed)
{
	int pos = this->findPosOfDog(name, breed);
	if (pos == -1)
		return Dog{};
	return this->dogs[pos];
}

int Repository::findPosOfDog(const std::string & name, const std::string & breed)
{
	if (dogs.size() == 0)
		return -1;

	for (size_t i = 0; i < this->dogs.size(); i++) {
		Dog d = this->dogs[i];
		if (d.getName() == name && d.getBreed() == breed)
			return i;
	}
	return -1;
}

void Repository::readFromFile()
{
	ifstream file(this->filename);

	if (!file.is_open())
		throw FileException("File could not be opened");

	Dog d;

	while (file >> d)
		this->dogs.push_back(d);

	file.close();
}

void Repository::writeToFile()
{
	ofstream file(this->filename);
	
	if (!file.is_open())
		throw FileException("File could not be opened");

	for (auto d : this->dogs)
		file << d << endl;

	file.close();
}
