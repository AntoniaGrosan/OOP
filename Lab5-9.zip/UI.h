#pragma once
#include "Controller.h"
#include <vector>

class UI
{
private:
	Controller ctrl;

public:
	UI(const Controller c) : ctrl{ c } {};
	void run();

private:
	static void printMenu();
	static void printAdministratorMenu();
	static void printUserMenu();
	static void printAdoptListMenu();

	//Administrator:
	void addDogRepo();
	void deleteDogRepo();
	void updateDogRepo();
	void seeDogsRepo();

	//User:
	void seeDogsShelterOneByOne();
	void seeFilteredDogs();
	void seeAdoptionList();
	void savePlaylistToFile();
};
