#pragma once
#include "FileList.h"
class HTMLFile : public FileList
{
public:
	HTMLFile(const std::string& filename) : FileList { filename }{};

	void writeToFile() override;
	void displayAdoptList() const override;
};

