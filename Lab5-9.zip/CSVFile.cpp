#include "CSVFile.h"
#include <fstream>
#include <Windows.h>
#include "RepoExceptions.h"

using namespace std;

void CSVFile::writeToFile()
{
	ofstream f(this->filename);

	if (!f.is_open())
		throw FileException("The file could not be opened!");

	for (auto d : this->dogs)
		f << d.getBreed() << "," << d.getName() << "," << d.getAge() << "," << d.getLink() << endl;

	f.close();
}

void CSVFile::displayAdoptList() const
{
	//string aux = "\"" + this->filename + "\"";
	string aux = this->filename;
	ShellExecuteA(NULL, NULL, "notepad.exe", aux.c_str(), NULL, SW_SHOWMAXIMIZED);
}

