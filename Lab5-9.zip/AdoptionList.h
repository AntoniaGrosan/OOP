#pragma once
#include "Dog.h"
#include <vector>

class AdoptionList
{
protected:
	std::vector<Dog> dogs;
	int current;

public:
	AdoptionList();

	//Adds a dog to the adoption list
	void Add(const Dog dog);

	Dog getCurrentDog();

	// Shows the first dog from the adoption list.
	void show();

	// Shows the next dog in the adoption list.
	void next();

	// Checks if the adoption list is empty.
	bool isEmpty();
	
	virtual ~AdoptionList() {}
};

