#pragma once

class Tests {
public:
	static void TestDog();
	static void TestDogException();
	static void TestRepo();
	static void TestController();
	static void TestAdoptionList();

	static void TestAll();
};
