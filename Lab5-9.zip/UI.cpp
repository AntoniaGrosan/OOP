#include "UI.h"
#include "DogValidator.h"
#include "RepoExceptions.h"
#include "CSVFile.h"
#include "HTMLFile.h"
#include <iostream>
#include <string>
using namespace std;


void UI::printMenu()
{
	cout << endl;
	cout << "Choose the mode you want:" << endl;
	cout << "1 - Administrator mode." << endl;
	cout << "2 - User mode." << endl;
	cout << "0 - Exit." << endl;
}

void UI::printAdministratorMenu()
{
	cout << endl << "Possible commands: " << endl;
	cout << "\t 1 - Add dog." << endl;
	cout << "\t 2 - Delete dog." << endl;
	cout << "\t 3 - Update dog." << endl;
	cout << "\t 4 - Display all dogs." << endl;
	cout << "\t 0 - Back." << endl;
}

void UI::printUserMenu()
{
	cout << endl << "Possible commands: " << endl;
	cout << "\t 1 - See all the dogs in the shelter(repository)." << endl;
	cout << "\t 2 - See all the dogs of a given breed, having an age less than a given number." << endl;
	cout << "\t 3 - See all the dogs from the adoption list." << endl;
	cout << "\t 0 - Back." << endl;
}

void UI::addDogRepo()
{
	cout << "Enter the name: ";
	string name;
	getline(cin, name);

	cout << "Enter the breed: ";
	string breed;
	getline(cin, breed);

	int age = 0;
	cout << "Enter the age: ";
	cin >> age;
	cin.ignore();

	cout << "Enter photo link: ";
	string photoLink;
	getline(cin, photoLink);

	bool ok = 0;
	try {
		this->ctrl.addDogToRepo(breed, name, age, photoLink);
	}
	catch (DogException& exc) {
		for (std::string e : exc.getErrors())
			cout << e << endl;
	}
	catch (RepositoryException& e)
	{
		cout << e.what() << endl;
	}
	catch (FileException& e)
	{
		cout << e.what() << endl;
	}
}

void UI::deleteDogRepo()
{
	cout << "Enter the name: ";
	string name;
	getline(cin, name);

	cout << "Enter the breed: ";
	string breed;
	getline(cin, breed);
	try {
		this->ctrl.deleteDogFromRepo(breed, name);
	}
	catch (RepositoryException& e)
	{
		cout << e.what() << endl;
	}
	catch (FileException& e)
	{
		cout << e.what() << endl;
	}
}

void UI::updateDogRepo()
{
	cout << "Enter the name of the dog you want to update: ";
	string name;
	getline(cin, name);

	cout << "Enter the breed of the dog you want to update: ";
	string breed;
	getline(cin, breed);

	int age = 0;
	cout << "Enter new age: " ;
	cin >> age;
	cin.ignore();

	cout << "Enter new photo link: ";
	string photoLink;
	getline(cin, photoLink);

	try {
		this->ctrl.updateDogFromRepo(name, breed, age, photoLink);
	}
	catch (RepositoryException& e)
	{
		cout << e.what() << endl;
	}
	catch (FileException& e)
	{
		cout << e.what() << endl;
	}
}

void UI::seeDogsRepo()
{
	std::vector<Dog> dogsFromRepo = this->ctrl.getRepo().getDogsR();
	if (dogsFromRepo.size() == 0) {
		cout << "There are no dogs to show. The repo is empty." << endl;
		return;
	}

	for (size_t i = 0; i < dogsFromRepo.size(); i++) {
		Dog d = dogsFromRepo[i];
		cout << "Name: " << d.getName() << "; Breed: " << d.getBreed() << "; Age: " << d.getAge() << endl;
	}
}

void UI::seeDogsShelterOneByOne()
{
	std::vector<Dog> dogs = this->ctrl.getRepo().getDogsR();

	if (dogs.size() == 0) {
		cout << "There are no dogs to show. The repo is empty." << endl;
		return;
	}

	int i = 0;
	while(true){
		Dog d = dogs[i];
		cout << "Name: " << d.getName() << "; Breed: " << d.getBreed() << "; Age: " << d.getAge() << endl;
		d.showPhoto();
		cout << "Do you want to adopt the dog?" << endl;
		cout << "1 - Yes." << endl;
		cout << "2 - No.Show next one." << endl;
		int cmd = 0;
		cin >> cmd;
		cin.ignore();
		if (cmd == 1) {
			try {
				this->ctrl.addToAdoptionList(d);
			}
			catch (FileException& e)
			{
				cout << e.what() << endl;
			}
			break;
		}
		if (cmd == 2) {
			i++;
			if (i == dogs.size())
				i = 0;
		}
	}
	this->ctrl.saveAdoptionList();
}

void UI::seeFilteredDogs()
{
	cout << "Enter the breed: ";
	string breed;
	getline(cin, breed);

	int age = 0;
	cout << "Enter the age: ";
	cin >> age;
	cin.ignore();

	Repository filteredDogs = this->ctrl.filterByBreedAndAge(breed, age);
	int size = filteredDogs.getSize();
	if ( size == 0) {
		cout << "No such dogs in the shelter!" << endl;
		return;
	}

	std::vector<Dog> dogs = filteredDogs.getDogsR();

	int i = 0;
	while (true) {
		Dog d = dogs[i];
		cout << "Name: " << d.getName() << "; Breed: " << d.getBreed() << "; Age: " << d.getAge() << endl;
		d.showPhoto();
		cout << "Do you want to adopt the dog?" << endl;
		cout << "1 - Yes." << endl;
		cout << "2 - No.Show next one." << endl;
		int cmd = 0;
		cin >> cmd;
		cin.ignore();
		if (cmd == 1) {
			try {
				this->ctrl.addToAdoptionList(d);
			}
			catch (FileException& e)
			{
				cout << e.what() << endl;
			}
			break;
		}
		if (cmd == 2) {
			i++;
			if (i == dogs.size())
				i = 0;
		}
	}
	this->ctrl.saveAdoptionList();
}

void UI::seeAdoptionList()
{
	if (this->ctrl.getAdoptList() == nullptr){
		cout << "There are no dogs to show. The adoption list is empty." << endl;
		return;
	}
	this->ctrl.startShowing();
	Dog d = this->ctrl.getAdoptList()->getCurrentDog();
	cout << "Showing: " << d.getName() << ", " << d.getBreed() << ", " << d.getAge() << endl;
	
	while (true){
		cout << "1 - Next dog" << endl;
		cout << "0 - Stop showing" << endl;
		int cmd = 0;
		cin >> cmd;
		cin.ignore();
		if (cmd == 1) {
			this->ctrl.nextDog();
			Dog doggo = this->ctrl.getAdoptList()->getCurrentDog();
			cout << "Showing: " << d.getName() << ", " << d.getBreed() << ", " << d.getAge() << endl;
		}
		else if (cmd == 0)
			break;
	}
}

void UI::savePlaylistToFile()
{
	std::string filename;
	cout << "Input the file name (absolute path): ";
	getline(cin, filename);

	try
	{
		this->ctrl.saveAdoptionList();

		if (this->ctrl.getAdoptList() == nullptr)
		{
			cout << "Adoption list cannot be displayed!" << endl;
			return;
		}
	}
	catch (FileException& e)
	{
		cout << e.what() << endl;
	}
}


void UI::run()
{

	while (true) {

		UI::printMenu();
		int command = 0;
		cout << "Input the comand: ";
		cin >> command;
		cin.ignore();
		if (command == 0)
			break;

		if (command == 1) {

			while (true) {

				UI::printAdministratorMenu();
				int cmdAdmin = 0;
				cout <<endl << "Input the command:";
				cin >> cmdAdmin;
				cin.ignore();

				if (cmdAdmin == 0)
					break;

				if (cmdAdmin == 1)
					UI::addDogRepo();

				if (cmdAdmin == 2)
					UI::deleteDogRepo();

				if (cmdAdmin == 3)
					UI::updateDogRepo();

				if (cmdAdmin == 4)
					UI::seeDogsRepo();
			}
		}

		if (command == 2) {

			while (true) {
				this->printUserMenu();
				int cmdUser = 0;
				cout << endl <<"Input the command:";
				cin >> cmdUser;
				cin.ignore();

				if (cmdUser == 0)
					break;

				if (cmdUser == 1)
					this->seeDogsShelterOneByOne();

				if (cmdUser == 2)
					this->seeFilteredDogs();
				
				if (cmdUser == 3) 
					this->ctrl.openAdoptionList();
			}
		}
	}
}

