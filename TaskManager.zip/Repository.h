#pragma once
#include "Domain.h"
#include <vector>

class Repository
{
private:
	std::vector<Programmer> programmers;
	std::vector<Task> tasks;
	std::string programmers_filename;
	std::string tasks_filename;

	void read_programmers();
	void read_tasks();
	void save_tasks();

public:
	Repository(std::string programmers_filename, std::string tasks_filename);

	std::vector<Programmer> get_programmers() { return programmers; }
	std::vector<Task> get_tasks() { return tasks; }

	void add_task(Task task);
	void remove_task(std::string description_task);
	void start_task(std::string description_task, std::string programmer_id);
	bool end_task(std::string description_task, std::string programmer_id);
	~Repository() {};
};