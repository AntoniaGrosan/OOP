#pragma once
#include <string>

class Programmer
{
private:
	std::string id;
	std::string name;

public:
	Programmer(std::string id, std::string name) : id{ id }, name{ name } {};
	Programmer();

	std::string get_name() { return this->name; }
	std::string get_id() { return this->id; }
	~Programmer() {};
};

class Task
{
private:
	std::string description;
	std::string status;
	std::string programmer_id;

public:
	Task(std::string description, std::string status, std::string programmer_id) : description{ description }, status{ status }, programmer_id{ programmer_id } {};
	Task();

	std::string get_description() { return this->description; }
	std::string get_status() { return this->status; }
	std::string get_programmer_id() { return this->programmer_id; }

	void set_status(std::string status) { this->status = status; }
	void set_programmer_id(std::string programmer_id) { this->programmer_id = programmer_id; }

	~Task() {};
};