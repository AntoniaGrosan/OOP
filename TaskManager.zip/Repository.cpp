#include "Repository.h"
#include <fstream>
#include <string.h>
#include <sstream>

void Repository::read_programmers()
{
	std::ifstream f(this->programmers_filename);

	if (!f.is_open())
		throw std::exception{ "The file could not be opened!" };

	std::string line;
	while (getline(f, line))
	{
		std::vector<std::string> result;
		std::stringstream ss(line);
		std::string token;
		while (getline(ss, token, ' '))
		{
			result.push_back(token);
		}

		if (result.size() == 2)
		{
			Programmer programmer{ result[0], result[1] };
			this->programmers.push_back(programmer);
		}
	}
	f.close();
}

void Repository::read_tasks()
{
	std::ifstream f(this->tasks_filename);

	if (!f.is_open())
		throw std::exception{ "The file could not be opened!" };

	std::string line;
	while (getline(f, line))
	{
		std::vector<std::string> result;
		std::stringstream ss(line);
		std::string token;
		while (getline(ss, token, ' '))
		{
			result.push_back(token);
		}

		if (result.size() == 3)
		{
			Task task{ result[0], result[1], result[2] };
			this->tasks.push_back(task);
		}
		else if (result.size() == 2)
		{
			Task task{ result[0], result[1], "" };
			this->tasks.push_back(task);
		}
	}
	f.close();
}

void Repository::save_tasks()
{
	std::ofstream f(this->tasks_filename);

	std::stringstream line;
	for (Task task : tasks)
	{
		line << task.get_description() << " " << task.get_status() << " ";
		if (task.get_programmer_id() != "")
			line << task.get_programmer_id();
		line << "\n";
		f << line.rdbuf();
	}
	f.close();
}

Repository::Repository(std::string programmers_filename, std::string tasks_filename) : programmers_filename{ programmers_filename }, tasks_filename{ tasks_filename }
{
	this->read_programmers();
	this->read_tasks();
}

void Repository::add_task(Task task)
{
	this->tasks.push_back(task);
	this->save_tasks();
}

void Repository::remove_task(std::string description_task)
{
	int pos;
	for (int i = 0; i < tasks.size(); i++)
		if (tasks[i].get_description() == description_task)
		{
			pos = i;
			i = tasks.size();
		}
	for (int i = pos; i < tasks.size()-1; i++)
		tasks[i] = tasks[i + 1];
	tasks.pop_back();
	this->save_tasks();
}

void Repository::start_task(std::string description_task, std::string programmer_id)
{
	for(int i=0; i<tasks.size(); i++)
		if (tasks[i].get_description() == description_task)
		{
			tasks[i].set_status("in_progress");
			tasks[i].set_programmer_id(programmer_id);
		}
	this->save_tasks();
}

bool Repository::end_task(std::string description_task, std::string programmer_id)
{
	for (int i = 0; i<tasks.size(); i++)
		if (tasks[i].get_description() == description_task)
		{
			if (tasks[i].get_programmer_id() == programmer_id)
			{
				tasks[i].set_status("closed");
				this->save_tasks();
				return true;
			}
		}
	return false;
}
