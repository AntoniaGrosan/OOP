#pragma once

#include <QWidget>
#include "ui_ProgrammerView.h"
#include "TasksModel.h"
#include <qsortfilterproxymodel.h>

class ProgrammerView : public QWidget
{
	Q_OBJECT

public:
	ProgrammerView(TasksModel* model, Programmer &programmer, QWidget *parent = Q_NULLPTR);
	~ProgrammerView();

private:
	Ui::ProgrammerView ui;
	TasksModel *model;
	Programmer &programmer;

	void add_task_handler();
	void remove_task_handler();
	void start_task_handler();
	void end_task_handler();
};
