#include "TasksModel.h"

int TasksModel::rowCount(const QModelIndex & parent) const
{
	return repo.get_tasks().size();
}

int TasksModel::columnCount(const QModelIndex & parent) const
{
	return 3;
}

QVariant TasksModel::data(const QModelIndex & index, int role) const
{
	int row = index.row();
	int column = index.column();
	std::vector<Task> tasks = this->repo.get_tasks();
	
	if (role == Qt::DisplayRole)
	{
		switch (column)
		{
		case 0: return QString::fromStdString(tasks[row].get_description());
		case 1: return QString::fromStdString(tasks[row].get_status());
		case 2:	return QString::fromStdString(tasks[row].get_programmer_id());
		}
	}
	
	return QVariant();
}

QVariant TasksModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (role == Qt::DisplayRole)
	{
		if (orientation == Qt::Horizontal)
		{
			switch (section)
			{
			case 0: return QString("Description");
			case 1: return QString("Status");
			case 2: return QString("Programmer_id");
			}
		}
	}
	return QVariant();
}

void TasksModel::add_task(Task task, QModelIndex index)
{
	beginInsertRows(index, repo.get_tasks().size(), repo.get_tasks().size());
	repo.add_task(task);
	endInsertRows();
}

void TasksModel::remove_task(std::string description_task, QModelIndex index)
{
	beginRemoveRows(QModelIndex(), index.row(), index.row());
	repo.remove_task(description_task);
	endRemoveRows();
}

void TasksModel::start_task(std::string description_task, std::string programmer_id)
{
	repo.start_task(description_task, programmer_id);
	emit dataChanged(QModelIndex(), QModelIndex());
}

bool TasksModel::end_task(std::string description_task, std::string programmer_id)
{
	if (repo.end_task(description_task, programmer_id) == true)
	{
		emit dataChanged(QModelIndex(), QModelIndex());
		return true;
	}
	return false;
}