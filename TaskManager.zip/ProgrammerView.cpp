#include "ProgrammerView.h"
#include <iostream>
#include <qmessagebox.h>

ProgrammerView::ProgrammerView(TasksModel* model, Programmer &programmer, QWidget *parent) : model{ model }, programmer{ programmer }, QWidget { parent }
{
	ui.setupUi(this);
	/*QSortFilterProxyModel *proxyModel = new QSortFilterProxyModel();
	proxyModel->setSourceModel(model);
	proxyModel->sort(1, Qt::AscendingOrder);
	ui.tasksView->setModel(proxyModel);*/
	ui.tasksView->setModel(model);
	QWidget::setWindowTitle(QString::fromStdString(programmer.get_id()));
	ui.tasksView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
	
	QObject::connect(ui.add_task_button, &QPushButton::clicked, this, &ProgrammerView::add_task_handler);
	QObject::connect(ui.remove_task_button, &QPushButton::clicked, this, &ProgrammerView::remove_task_handler);
	QObject::connect(ui.start_task_button, &QPushButton::clicked, this, &ProgrammerView::start_task_handler);
	QObject::connect(ui.end_task_button, &QPushButton::clicked, this, &ProgrammerView::end_task_handler);

}

ProgrammerView::~ProgrammerView()
{
}

void ProgrammerView::add_task_handler()
{
	std::string description = ui.description_line_edt->text().toStdString();
	std::string status = "open";
	std::string programmer_id = "";

	Task task{ description, status, programmer_id };
	this->model->add_task(task, QModelIndex());
}

void ProgrammerView::remove_task_handler()
{
	QModelIndexList selection = ui.tasksView->selectionModel()->selectedRows();
	QString hey = ui.tasksView->model()->data(selection[0]).toString();
	std::string description_task = hey.toStdString();
	this->model->remove_task(description_task, selection[0]);
}

void ProgrammerView::start_task_handler()
{
	QModelIndexList selection = ui.tasksView->selectionModel()->selectedRows();
	for (QModelIndex index : selection)
	{
		QString hey = ui.tasksView->model()->data(index).toString();
		std::string description_task = hey.toStdString();
		this->model->start_task(description_task, programmer.get_id());
	}
}

void ProgrammerView::end_task_handler()
{
	QModelIndexList selection = ui.tasksView->selectionModel()->selectedRows();
	for (QModelIndex index : selection)
	{
		QString hey = ui.tasksView->model()->data(index).toString();
		std::string description_task = hey.toStdString();
		if (this->model->end_task(description_task, programmer.get_id()) == false)
			QMessageBox::warning(this, "Warning", QString("Mind our own business, literally"));
	}
}