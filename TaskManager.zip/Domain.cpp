#include "Domain.h"

Programmer::Programmer()
{
	id = "00";
	name = "";
}

Task::Task()
{
	description = "";
	status = "";
	programmer_id = "";
}
