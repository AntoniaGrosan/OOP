#include <QtWidgets/QApplication>
#include "Repository.h"
#include "TasksModel.h"
#include "ProgrammerView.h"
#include <qsortfilterproxymodel.h>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	std::string programmers_filename = "Programmers.txt";
	std::string tasks_filename = "Tasks.txt";

	Repository repo{programmers_filename, tasks_filename};
	std::vector<Programmer> programmers = repo.get_programmers();
	std::vector<Task> tasks = repo.get_tasks();

	TasksModel* model = new TasksModel{ repo };
	ProgrammerView *view1 = new ProgrammerView(model, programmers[0]);
	ProgrammerView *view2 = new ProgrammerView(model, programmers[1]);
	ProgrammerView *view3 = new ProgrammerView(model, programmers[2]);

	view1->show();
	view2->show();
	view3->show();

	return a.exec();
}
