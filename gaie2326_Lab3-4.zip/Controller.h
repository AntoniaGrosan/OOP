#pragma once
#include "Repository.h"
#include "OperationsStack.h"

typedef struct
{
	OfferRepo* repo;
	OperationsStack* undoStack;
	OperationsStack* redoStack;
} Controller;

/*
Creates an offer controller.
*/
Controller * createController(OfferRepo * r, OperationsStack* undoS, OperationsStack* redoS);

/*
Destroys an offer rcontroller.
*/
void destroyController(Controller* c);

/*
Returns the repository.
Input : - c - controller
Output : - repository
*/
OfferRepo* getRepo(Controller* c);

/*
Adds an offer to the repository of offers.
Input:
- v - pointer to the OfferRepo
- ofr - offer
Output:
1 - if the offer was sucessfully added
0 - if the offer could not be added, as another offer with the same name already exists in the OfferRepo.
*/
int Add(Controller* c, char* type, char* address, int surface, int price);

/*
Deletes an offer from the repository of offers.
Input:
- v - pointer to the OfferRepo
- ofr - offer
Output:
1 - if the offer was sucessfully deleted
0 - if the offer could not be deleted, as the offer with the given name doesn't exist in the Offer repo.
*/
int Delete(Controller* c, char * type, char * address, int price, int surface);

/*
Updates the type of an offer from the repository of offers.
Input:
- v - pointer to the OfferRepo
- ofr - the offer which is going to be updated
- type - new type
Output:
1 - if the offer was sucessfully updated
0 - if the offer could not be updated, as the offer with the given address doesn't exist in the OfferRepo.
*/
UpdateOffer(Controller * c, Offer * of);

/*
Sorts a repo of offers ascendig by thier price;
input:
-v - the repo
output :
-v - the sorted repo
*/
OfferRepo * SortAscendingByPrice(OfferRepo * v);

/*
Sorts a repo of offers descendig by thier price;
input:
- v - the repo
output:
- v - the sorted repo
*/
OfferRepo * SortDescendingByPrice(OfferRepo * v);

/*
Filters a repo of offers. It creates a new repository type with the 
offers that have an adress which contain a given string;
input:
- c - the controller
- string - the string
output:
- res - the sorted repo
*/
OfferRepo* FilterByStrInAddress(Controller* c, char string[], char sorting[]);

OfferRepo* FilterByType(Controller * c, char givType[], int givSurf);
OfferRepo* FilterByType2(Controller * c, char givType[], int givPr);

int Undo(Controller* c);

int Redo(Controller* c);

void testsController();
