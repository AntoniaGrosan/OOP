#include "Offer.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

Offer*  create_offer(char * type, char * address, int surface, int price){
	Offer* ofr = (Offer*)malloc(sizeof(Offer));

	ofr->type = (char*)malloc(sizeof(char) * (strlen(type) + 1));
	strcpy(ofr->type, type);

	ofr->address = (char*)malloc(sizeof(char) * (strlen(address) + 1));
	strcpy(ofr->address, address);

	ofr->surface = surface;

	ofr->price = price;

	return ofr;
}

void destroy_offer(Offer * ofr)
{
	// free the memory which was allocated for the component fields
	if (ofr == NULL)
		return;
	free(ofr->type);
	free(ofr->address);

	// free the memory which was allocated for the offer structure
	free(ofr);
}

Offer* copy_offer(Offer* ofr)
{
	if (ofr == NULL)
		return NULL;

	Offer* newOffer = create_offer(get_type(ofr), get_address(ofr), get_surface(ofr),get_price(ofr));
	return newOffer;
}

char* get_type(Offer * ofr)
{
	return ofr->type;
}

char * get_address(Offer * ofr)
{
	return ofr->address;
}

int get_surface(Offer * ofr)
{
	return ofr->surface;
}

int get_price(Offer * ofr)
{
	return ofr->price;
}


void toString(Offer * ofr, char str[])
{
	sprintf(str, " %s, address %s, %d square meters, price %d euro", ofr->type, ofr->address, ofr->surface, ofr->price);
}


void test_offer()
{
	char* type = (char*)malloc(sizeof(char) * 50);
	char* address = (char*)malloc(sizeof(char) * 50);
	strcpy(type, "house");
	strcpy(address, "Dorobantiolor 33");
	int price = 50000;
	int surface = 43;

	Offer* ofr = create_offer(type, address ,price , surface);

	char* type1 = get_type(ofr);
	assert(strcmp(type1,type) == 0);

	char* address1 = get_address(ofr);
	assert(strcmp(address,address1) == 0);

	//assert(get_price(ofr) == 50000);
	//assert(get_surface(ofr) == 43);
	destroy_offer(ofr);
	free(type);
	free(address);
}
/*
reference - cannot be initialized like int& x; we dont need to dereference
pointer - can like int* x=NULL;
*/


