#pragma once

typedef struct {
	char* type;
	char* address;
	int surface, price;
}Offer;

Offer* create_offer(char* type, char* address, int surface, int price);

void destroy_offer(Offer* ofr);
Offer* copy_offer(Offer* ofr);
char* get_type(Offer* ofr);
char* get_address(Offer* ofr);
int get_surface(Offer* ofr);
int get_price(Offer* ofr);

void toString(Offer* ofr, char str[]);

void test_offer();
