#include "UI.h"
#include "Offer.h"
#include "Repository.h"
#include "Controller.h"
#include "DynamicArray.h"
#include "OperationsStack.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

UI * createUI(Controller * c)
{
	UI* ui = (UI*)malloc(sizeof(UI));
	ui->ctrl = c;

	return ui;
}

void destroyUI(UI * ui)
{
	// first destroy the controller
	destroyController(ui->ctrl);
	// free the UI memory
	free(ui);
}

/*
Prints the available menu for the problem
Input: -
Output: the menu is printed at the console
*/
void printMenu()
{
	printf("\n**********************************************************\n");
	printf("1 - Add an offer.\n");
	printf("2 - Delete an offer.\n");
	printf("3 - Update an offer.\n");
	printf("4 - Display all offers whose address contains a given string, sorted ascending or descending by their price.\n");
	printf("5 - Display all offers of a type, having the surface greater than a value.\n");
	printf("6 - Display all offers.\n");
	printf("7 - Undo.\n");
	printf("8 - Redo.\n");
	printf("9 - Print menu.\n");
	printf("10 - Display all offers of a type, having the price smaller than a value.\n");
	printf("0 - Exit.\n");
	printf("\n**********************************************************\n");
}

/*
Verifies if the given command is valid (is either 1,2,3,4 or 0)
Input: command - integer
Output: 1 - if the command is valid
0 - otherwise
*/
int validCommand(int command)
{
	if (command >= 0 && command <= 10)
		return 1;
	return 0;
}

int validateType(char type[]) {
	if ((strcmp(type, "house") != 0) && (strcmp(type, "apartment") != 0) && (strcmp(type, "penthouse") != 0))
		return 0;
	return 1;
}

/*
Reads an integer number from the keyboard. Asks for number while read errors encoutered.
Input: the message to be displayed when asking the user for input.
Returns the number.
*/
int readIntegerNumber(const char* message)
{
	char s[16];
	int res = 0;
	int flag = 0;
	int r = 0;

	while (flag == 0)
	{
		printf(message);
		scanf("%s", s);

		r = sscanf(s, "%d", &res);	// reads data from s and stores them as integer, if possible; returns 1 if successful
		flag = (r == 1);
		if (flag == 0)
			printf("Error reading number!\n");
	}
	return res;
}

void readStringWithSpaces(const char* message, int maxStrSize, char str[])
{
	printf(message);
	fgets(str, maxStrSize, stdin);
	// the newline is also read so we must eliminate it from the string
	int size = strlen(str) - 1;
	if (str[size] == '\n')
		str[size] = '\0';
}


int addOfferUI(UI* ui)
{
	// read the offer's data
	char address[50], type[50];
	int price = 0, surface = 0;

	printf("Input the type: ");
	scanf("%49s",type);

	if (validateType(type) == 1) {
		fgetc(stdin);
		readStringWithSpaces("Input the address: ", 50, address);

		surface = readIntegerNumber("Input the surface: ");

		price = readIntegerNumber("Input the price: ");

		return Add(ui->ctrl, type, address, surface, price);
	}
	else {
		printf("Invalid type!\n");
		return 0;
	}
}

int deleteOfferUI(UI* ui)
{
	// read the offer's data
	char address[50], type[50];
	int price = 0, surface = 0;

	printf("Input the type: ");
	scanf("%49s", type);

	if (validateType(type) == 1) {
		fgetc(stdin);
		readStringWithSpaces("Input the address: ", 50, address);

		surface = readIntegerNumber("Input the surface: ");

		price = readIntegerNumber("Input the price: ");

		return Delete(ui->ctrl, type, address, surface, price);
	}
	else {
		printf("Invalid type!\n");
		return 0;
	}
}

int updateOfferUI(UI* ui)
{
	// read the offer's data
	char address[50], type[50];
	int price = 0, surface = 0;

	printf("Input the type: ");
	scanf("%s", type);

	if (validateType(type) == 1) {
		fgetc(stdin);
		readStringWithSpaces("Input the address(from the list): ", 50, address);

		printf("Input the surface: ");
		scanf("%d", &surface);

		printf("Input the price: ");
		scanf("%d", &price);

		Offer* ofr = create_offer(type, address, surface, price);
		int res = UpdateOffer(ui->ctrl, ofr);
		return res;
	}
	else {
		printf("Invalid type!\n");
		return 0;
	}
}

void listAllOffers(UI* ui)
{
	OfferRepo* repo = getRepo(ui->ctrl);
	int length = getLength(repo);

	if (length == 0)
	{
		char* str = "There are no stored offers.";
		printf("%s \n", str);
	}

	for (int i = 0; i < getLength(repo); i++)
	{
		char str[200];
		toString(getOfferOnPos(repo, i), str);
		printf("%s\n", str);
	}
}

void listOffersByAdr(UI* ui)
{
	char string[50],sorting[50];

	fgetc(stdin);
	readStringWithSpaces("Input the string; input 'null' for no string: ", 50, string);

	printf("Do you want the offers to be shown descending(d) or ascending(a) by thier surface?\n");
	scanf("%s", sorting);

	if ((strcmp(sorting, "a") == 0) || (strcmp(sorting, "d") == 0)) {

		OfferRepo* res = FilterByStrInAddress(ui->ctrl, string, sorting);
		int length = getLength(res);
		if (length == 0)
		{
			printf("There are no offers containing the given string.");
		}
		else
		{
			for (int i = 0; i < length; i++)
			{
				char str[200];
				toString(getOfferOnPos(res, i), str);
				printf("%s\n", str);
			}
		}

		// now we must destroy the repository that was created for this operation
		destroyRepo(res);
	}
	else {
		printf("You must enter 'a' or 'd'!\n");
	}
}

void listOffersByType(UI* ui) {
	char type[50];
	int surf;

	printf("Input the type: ");
	scanf("%49s", type);

	if (validateType(type) == 1) {

		printf("Input the surface: ");
		scanf("%d", &surf);

		OfferRepo* res = FilterByType(ui->ctrl, type, surf);
		int length = getLength(res);
		if (length == 0)
		{
			printf("There are no offers having the given type and having the surface greater than the given value.");
		}
		else
		{
			for (int i = 0; i < length; i++)
			{
				char str[200];
				toString(getOfferOnPos(res, i), str);
				printf("%s\n", str);
			}
		}
		destroyRepo(res);
	}
	else {
		printf("Invalid type!\n");
		return;
	}
}

void listOffersByType2(UI* ui) {
	char type[50];
	int surf;

	printf("Input the type: ");
	scanf("%49s", type);
	if (validateType(type) == 1) {
		printf("Input the price: ");
		scanf("%d", &surf);

		OfferRepo* res = FilterByType2(ui->ctrl, type, surf);
		int length = getLength(res);
		if (length == 0)
		{
			printf("There are no offers having the given type and having the price smaller than the given value.");
		}
		else
		{
			for (int i = 0; i < length; i++)
			{
				char str[200];
				toString(getOfferOnPos(res, i), str);
				printf("%s\n", str);
			}
		}
		destroyRepo(res);
	}
	else {
		printf("Invalid type!\n");
	}
}

void startUI(UI * ui)
{
	printMenu();
	while (1)
	{
		int command = readIntegerNumber("Input command: ");

		while (validCommand(command) == 0){
			printf("Please input a valid command!\n");
			command = readIntegerNumber("Input command: ");
		}

		if (command == 0)
			break;

		switch (command) {

		case 1: {
			int res = addOfferUI(ui);
			if (res == 1)
				printf("Offer successfully added.\n");
			else
				printf("Error! Offer could not be added, as there is another offer with the same address!\n");
			break;
		}

		case 2: {
			int res = deleteOfferUI(ui);
			if (res == 1)
				printf("Offer successfully deleted.\n");
			else
				printf("Error! Offer could not be deleted!\n");
			break;
		}

		case 3: {
			int res = updateOfferUI(ui);
			if (res == 1)
				printf("Offer successfully updated.\n");
			else
				printf("Error! Offer could not be updated!\n");
			break;
		}

		case 4: {
			listOffersByAdr(ui);
			break;
		}

		case 5: {
			listOffersByType(ui);
			break;
		}

		case 6:{
			listAllOffers(ui);
			break;
		}
		case 7:{
			int res = Undo(ui->ctrl);
			if (res == 1)
				printf("Undo was successful.\n");
			else
				printf("No more undos to be made.\n");
			break;
		}
		case 8:{
			int res = Redo(ui->ctrl);
			if (res == 1)
				printf("Redo was successful.\n");
			else
				printf("No more redos to be made.\n");
			break;
		}
		case 9: {
			printMenu();
			break;
		}
		case 10: {
			listOffersByType2(ui);
			break;
		}
		}
	}
}
