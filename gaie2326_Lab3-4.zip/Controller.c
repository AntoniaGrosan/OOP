#include "Controller.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

Controller * createController(OfferRepo * r, OperationsStack* undoS, OperationsStack* redoS)
{
	Controller* c = (Controller*)malloc(sizeof(Controller));
	c->repo = r;
	c->undoStack = undoS;
	c->redoStack = redoS;
	return c;
}

void destroyController(Controller * c)
{
	// first destroy the repository inside
	destroyRepo(c->repo);
	destroyStack(c->undoStack);
	destroyStack(c->redoStack);
	// then free the memory
	free(c);
}

OfferRepo * getRepo(Controller * c)
{
	return c->repo;
}

int Add(Controller * c, char * type, char * address, int surface, int price)
{
	Offer* of = create_offer(type, address, surface, price);

	int res = addOffer(c->repo, of);
	// if the offer was not added - destroy it (as it will not be destroyed by the repository)

	if (res == 1) // if the offer was successfully added - register the operation
	{
		Operation* o = createOperation(of, "add");
		push(c->undoStack, o);
		// once added, the operation can be destroyed (a copy of the operation was added)
		destroyOperation(o);
	}

	destroy_offer(of);
	return res;
}

int Delete(Controller * c, char * type, char * address, int surface, int price)
{
	Offer* of = create_offer(type, address, surface, price);
	int res = deleteOffer(c->repo, of);

	if (res == 1)
	{
		Operation* o = createOperation(of, "remove");
		push(c->undoStack, o);
		destroyOperation(o);
	}

	destroy_offer(of);
	return res;
}

int UpdateOffer(Controller * c, Offer * of)
{
	int res = updateOffer(c->repo, of);

	if (res == 1)
	{
		Operation* o = createOperation(findByAdr(c->repo, get_address(of)), "update");
		push(c->undoStack, o);
		destroyOperation(o);
	}
	destroy_offer(of);
	return res;
}

OfferRepo * FilterByStrInAddress(Controller * c, char string[],char sorting[])
{
	OfferRepo* res = createRepo();

	if (strcmp(string, "null") == 0)
		for (int i = 0; i < getLength(c->repo); i++){
			Offer* ofr = getOfferOnPos(c->repo, i);
			addOffer(res, ofr);
		}
	else
		for (int i = 0; i < getLength(c->repo); i++){
			Offer* ofr = getOfferOnPos(c->repo, i);
			if (strstr(get_address(ofr), string) != NULL){
				Offer* newOffer = create_offer(ofr->type, ofr->address, ofr->surface, ofr->price);
				addOffer(res, newOffer);
				destroy_offer(newOffer);
			}
		}
	if (strcmp(sorting, "a") == 0)
		res = SortAscendingByPrice(res);
	if (strcmp(sorting, "d") == 0)
		res = SortDescendingByPrice(res);
	return res;
}


OfferRepo* FilterByType(Controller * c, char givType[], int givSurf) {
	OfferRepo* res = createRepo();

	for (int i = 0; i < getLength(c->repo); i++) {
		Offer* ofr = getOfferOnPos(c->repo, i);
		if ( (strcmp(get_type(ofr), givType) == 0) && (get_surface(ofr) > givSurf) ) {
			Offer* newOffer = create_offer(ofr->type, ofr->address, ofr->surface, ofr->price);
			addOffer(res, newOffer);
			destroy_offer(newOffer);
		}
	}
	return res;
}

OfferRepo* FilterByType2(Controller * c, char givType[], int givPr[]) {
	OfferRepo* res = createRepo();

	for (int i = 0; i < getLength(c->repo); i++) {
		Offer* ofr = getOfferOnPos(c->repo, i);
		if ((strcmp(get_type(ofr), givType) == 0) && (get_price(ofr) < givPr)) {
			Offer* newOffer = create_offer(ofr->type, ofr->address, ofr->surface, ofr->price);
			addOffer(res, newOffer);
			destroy_offer(newOffer);
		}
	}
	return res;
}

OfferRepo * SortAscendingByPrice(OfferRepo * v)
{
	Offer* aux = getDA(v->offers, 0);
	int Len = getLength(v);
	for (int i = 0; i < Len - 1; i++)
		for (int j = i + 1; j < Len; j++)
			if (get_price(getDA(v->offers, i)) > get_price(getDA(v->offers, j))) {
				aux = getDA(v->offers, i);
				setDA(v->offers, i, getDA(v->offers, j));
				setDA(v->offers, j, aux);
			}
	return v;
}

OfferRepo * SortDescendingByPrice(OfferRepo * v)
{
	Offer* aux = getDA(v->offers, 0);
	int Len = getLength(v);
	for (int i = 0; i < Len - 1; i++)
		for (int j = i + 1; j < Len; j++)
			if (get_price(getDA(v->offers, i)) < get_price(getDA(v->offers, j))) {
				aux = getDA(v->offers, i);
				setDA(v->offers, i, getDA(v->offers, j));
				setDA(v->offers, j, aux);
			}
	return v;
}

int Undo(Controller* c)
{
	if (isEmpty(c->undoStack))
		return 0;

	int res = 0;
	Operation* operation = pop(c->undoStack);

	if (strcmp(getOperationType(operation), "add") == 0){
		Offer* ofr = getOffer(operation);
		//res = deleteOffer(c->repo, ofr);
		char address[50];
		strcpy(address, get_address(ofr));
		Operation* op = createOperation(ofr, "remove");
		push(c->redoStack, op);
		destroyOperation(op);
		res = deleteOffer(c->repo, findByAdr(c->repo,address));
	}

	else if (strcmp(getOperationType(operation), "remove") == 0){
		Offer* ofr = getOffer(operation);
		//res = addOffer(c->repo, ofr);
		Operation* op = createOperation(ofr, "remove");
		push(c->redoStack, op);
		destroyOperation(op);
		res = addOffer(c->repo, ofr);
	}

	else if (strcmp(getOperationType(operation), "update") == 0){
		Offer* ofr = getOffer(operation);
		//res = updateOffer(c->repo, ofr);	
		char address[50];
		strcpy(address, get_address(ofr));
		Operation* op = createOperation(findByAdr(c->repo,address), "update");
		push(c->redoStack, op);
		destroyOperation(op);
		res = updateOffer(c->repo, ofr);
	}

	// the operation must be destroyed
	destroyOperation(operation);

	return 1;
}

int Redo(Controller* c)
{
	if (isEmpty(c->redoStack))
		return 0;

	int res = 0;
	Operation* operation = pop(c->redoStack);

	if (strcmp(getOperationType(operation), "add") == 0) {
		Offer* ofr = getOffer(operation);
		//res = addOffer(c->repo, ofr);
		char address[50];
		strcpy(address, get_address(ofr));
		Operation* op = createOperation(ofr, "remove");
		push(c->undoStack, op);
		destroyOperation(op);
		res = deleteOffer(c->repo, findByAdr(c->repo, address));
	}
	else if (strcmp(getOperationType(operation), "remove") == 0) {
		Offer* ofr = getOffer(operation);
		//res = deleteOffer(c->repo, ofr);
		Operation* op = createOperation(ofr, "add");
		push(c->undoStack, op);
		destroyOperation(op);
		res = addOffer(c->repo, ofr);
	}
	else if (strcmp(getOperationType(operation), "update") == 0) {
		Offer* ofr = getOffer(operation);
		//res = updateOffer(c->repo, ofr);
		char address[50];
		strcpy(address, get_address(ofr));
		Operation* op = createOperation(ofr, "update");
		push(c->undoStack, op);
		destroyOperation(op);
		res = updateOffer(c->repo, findByAdr(c->repo, address));
	}

	// the operation must be destroyed
	destroyOperation(operation);

	return 1;
}


// Tests
void initControllerForTests(Controller* v)
{
	Add(v, "house", "Ioan Slavici 4/18", 13, 40000);
}

void test_Add()
{

	OfferRepo* v = createRepo();
	OperationsStack* undoStack = createStack();
	OperationsStack* redoStack = createStack();
	Controller* c = createController(v, undoStack, redoStack);
	initControllerForTests(c);
	assert(getLength(c->repo) == 1);

	assert(Add(c, "house", "I.L. Caragiale 5/6", 4, 50000) == 1);
	assert(getLength(c->repo) == 2);

	assert(Add(c, "house", "I.L. Caragiale 5/6", 4, 50000) == 0);

	destroyController(c);
}

void test_Delete()
{
	OfferRepo* v = createRepo();
	OperationsStack* undoStack = createStack();
	OperationsStack* redoStack = createStack();
	Controller* c = createController(v, undoStack, redoStack);
	initControllerForTests(c);

	assert(Delete(c, "house", "Ioan Slavici 4/18", 13, 40000) == 1);

	assert(getLength(c->repo) == 0);

	assert(Delete(c, "house", "Ioan Slavici 4/18", 13, 40000) == 0);

	destroyController(c); 
}

void test_Updates()
{
	OfferRepo* v = createRepo();
	OperationsStack* undoStack = createStack();
	OperationsStack* redoStack = createStack();
	Controller* c = createController(v, undoStack, redoStack);
	initControllerForTests(c);
	Offer* of = create_offer("penthouse", "Ioan Slavici 4/18", 143, 49000);
	assert(UpdateOffer(c, of) == 1);
	destroyController(c);
}

void test_Filter()
{
	OfferRepo* v = createRepo();
	OperationsStack* undoStack = createStack();
	OperationsStack* redoStack = createStack();
	Controller* c = createController(v, undoStack, redoStack);

	initControllerForTests(c);
	Add(c, "penthouse", "I.L. Caragiale 5/6", 4, 250000);
	Add(c, "apartment", "Ioan Slavici 4/43", 4, 370000);
	Add(c, "house", "I.L. Caragiale 79", 4, 63000);
	Add(c, "penthouse", "Bd. Bucuresti 3A", 4, 100000);
	Add(c, "house", "I.L. Caragiale 50B", 4, 51000);

	OfferRepo* r = FilterByStrInAddress(c, "arag","a");
	assert(strcmp(get_address(getDA(r->offers,0)),"I.L. Caragiale 50B") == 0);
	Offer* ofr = create_offer("penthouse", "I.L. Caragiale 5/6", 42, 250000);

	destroy_offer(ofr);
	destroyRepo(r);
	destroyController(c);
}

void testsController()
{
	test_Add();
	test_Delete();
	test_Updates();
	test_Filter();
}
