#include "Repository.h"
#include "Offer.h"
#include "DynamicArray.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

OfferRepo * createRepo()
{
	OfferRepo* v = (OfferRepo*)malloc(sizeof(OfferRepo));
	v->offers = createDA(CAPACITY);
	return v;
}

void destroyRepo(OfferRepo * v)
{
	if (v == NULL)
		return;
	destroyDA(v->offers);
	free(v);
}


Offer* findByAdr(OfferRepo * v, char* adr)
{
	if (v == NULL)
		return NULL;
	int pos = findPosOfOffer(v, adr);
	if (pos == -1)
		return NULL;
	return getDA(v->offers, pos);
}


Offer* getOfferOnPos(OfferRepo * v, int pos)
{
	if (pos < 0 || pos >= getLengthDA(v->offers))
		return NULL;
	return getDA(v->offers, pos);
}


int findPosOfOffer(OfferRepo * v, char* adr)
{
	if (v == NULL)
		return -1;

	for (int i = 0; i < getLengthDA(v->offers); i++)
	{
		Offer* ofr = getDA(v->offers, i);
		if (strcmp(ofr->address, adr) == 0)
			return i;
	}
	return -1;
}


int addOffer(OfferRepo * v, Offer * ofr)
{
	if (v == NULL)
		return 0;

	if (findByAdr(v, ofr->address) != NULL)
		return 0;

	Offer* copyOfr = copy_offer(ofr);
	addDA(v->offers, copyOfr);

	return 1;
}


int deleteOffer(OfferRepo * v, Offer * ofr)
{
	if (v == NULL)
		return 0;

	int pos = findPosOfOffer(v, ofr->address);

	if (pos == -1)
		return 0;

	Offer * o = getDA(v->offers, pos);
	destroy_offer(o);

	deleteDA(v->offers, pos);

	return 1;
}


int updateOffer(OfferRepo * v, Offer* ofr)
{
	if (findByAdr(v, ofr->address) == NULL)
		return 0;

	int pos = findPosOfOffer(v, ofr->address);

	//setDA(v->offers, pos, ofr);
	getDA(v->offers, pos)->price = ofr->price;
	getDA(v->offers, pos)->surface = ofr->surface;
	return 1;
}

int getLength(OfferRepo * v)
{
	return getLengthDA(v->offers);
}


// Tests
void initRepoForTests(OfferRepo* v)
{
	Offer* o = create_offer("house", "Ioan Slavici 4/18", 13, 40000);
	addOffer(v, o);
	destroy_offer(o);
}

void testAdd()
{
	OfferRepo* v = createRepo();
	initRepoForTests(v);
	assert(getLength(v) == 1);

	Offer* o = create_offer("house", "I.L. Caragiale 5/6", 4, 50000);
	assert(addOffer(v, o) == 1);
	assert(getLength(v) == 2);

	assert(addOffer(v, o) == 0);

	destroy_offer(o);
	destroyRepo(v);
}

void testDelete()
{
	OfferRepo* v = createRepo();
	initRepoForTests(v);
	Offer* o = create_offer("house", "Ioan Slavici 4/18", 13, 40000);
	assert(deleteOffer(v, o) == 1);

	assert(getLength(v) == 0);

	assert(deleteOffer(v, o) == 0);

	destroy_offer(o);
	destroyRepo(v);
}

void testUpdates()
{
	OfferRepo* v = createRepo();
	initRepoForTests(v);
	Offer* of = create_offer("penthouse", "Ioan Slavici 4/18", 130, 99000);
	assert(updateOffer(v, of) == 1);
	destroy_offer(of);
	destroyRepo(v);
}

void testSort()
{
	OfferRepo* v = createRepo();
	initRepoForTests(v);
	Offer* o1 = create_offer("house", "I.L. Caragiale 5/6", 42, 50000);
	Offer* o2 = create_offer("house", "I.L. Caragiale 6/6", 54, 16000);
	Offer* o3 = create_offer("house", "I.L. Caragiale 8/6", 60, 58000);
	Offer* o4 = create_offer("house", "I.L. Caragiale 10/6", 3, 70000);

	addOffer(v, o1);
	addOffer(v, o2);
	addOffer(v, o3);
	addOffer(v, o4);

	v = SortAscendingByPrice(v);
	assert((strcmp(get_address(getDA(v->offers, 0)),get_address(o2)))==0);
	assert(get_price(getDA(v->offers, 0)) == 16000);
	assert(get_price(getDA(v->offers, 1)) == 40000);
	assert(get_price(getDA(v->offers, 2)) == 50000);

	destroyRepo(v);
	destroy_offer(o1);
	destroy_offer(o2);
	destroy_offer(o3);
	destroy_offer(o4);
}

void testsRepo()
{
	testAdd();
	testDelete();
	testUpdates();
	testSort();
}
