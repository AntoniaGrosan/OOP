#include "Offer.h"
#include "Repository.h"
#include "Controller.h"
#include "UI.h"
#include <crtdbg.h>
#include <stdio.h>

int main() {
	testsController();
	test_offer();
	testsRepo();
	testsDynamicArray();
	testsStack();
	
	OfferRepo* repo = createRepo();
	OperationsStack* undoStack = createStack();
	OperationsStack* redoStack = createStack();
	Controller* c = createController(repo, undoStack, redoStack);

	Add(c, "house", "Calea Turzii 80", 35, 60000);
	Add(c, "apartment", "Bd. Republicii 35A", 54, 1380000);
	Add(c, "house", "Independentei 16", 80, 86000);
	Add(c, "penthouse", "I.L. Caragiale 5/6", 100, 250000);
	Add(c, "apartment", "Ioan Slavici 4/43", 30, 370000);
	Add(c, "house", "I.L. Caragiale 79", 55, 63000);
	Add(c, "penthouse", "Bd. Bucuresti 3A", 68, 100000);
	Add(c, "house", "I.L. Caragiale 50B", 46, 51000);
	Add(c, "apartment", "I.L. Caragiale 10", 25, 21000);
	Add(c, "apartment", "Dorobantilor 4/43", 40, 200000);
	Add(c, "house", "I.L. Caragiale 79", 56, 63000);
	Add(c, "apartment", "Bd. Republicii 35A", 90, 1380000);
	Add(c, "house", "Independentei 16", 120, 86000);

	UI* ui = createUI(c);

	startUI(ui);

	destroyUI(ui);

	_CrtDumpMemoryLeaks();
	
	return 0;
}

