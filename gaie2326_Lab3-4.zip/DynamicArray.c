#include "DynamicArray.h"
#include <stdlib.h>
#include <assert.h>
#include <string.h>

DynamicArray* createDA(int capacity)
{
	DynamicArray* da = (DynamicArray*)malloc(sizeof(DynamicArray));
	if (da == NULL)
		return NULL;

	da->capacity = capacity;
	da->length = 0;

	da->elems = (TElement*)malloc(capacity * sizeof(TElement));
	if (da->elems == NULL)
		return NULL;

	return da;
}


void destroyDA(DynamicArray* arr)
{
	if (arr == NULL)
		return;

	for (int i = 0; i < arr->length; i++)
		destroy_offer(arr->elems[i]);

	free(arr->elems);
	arr->elems = NULL;

	free(arr);
	arr = NULL;
}

void setDA(DynamicArray* arr, int pos, Offer* newo)
{
	arr->elems[pos] = newo;
}

// Resizes the array, allocating more space.
// If more space cannot be allocated, returns -1, else it returns 0.
int resize(DynamicArray* arr)
{
	if (arr == NULL)
		return -1;

	arr->capacity *= 2;

	TElement* aux = (TElement*)malloc(arr->capacity * sizeof(TElement));
	if (aux == NULL)
		return -1;
	for (int i = 0; i < arr->length; i++)
		aux[i] = arr->elems[i];
	free(arr->elems);
	arr->elems = aux;

	return 0;
}

void addDA(DynamicArray* arr, TElement t)
{
	if (arr == NULL)
		return;
	if (arr->elems == NULL)
		return;

	// resize the array, if necessary
	if (arr->length == arr->capacity)
		resize(arr);
	arr->elems[arr->length++] = t;
}

void deleteDA(DynamicArray* arr, int pos)
{
	if (arr == NULL)
		return;
	if (arr->elems == NULL)
		return;

	if (pos < 0 || pos >= arr->length)
		return;

	// !!! Considering the code below, we will no longer have access to the allocated memory.
	// How can we avoid a memory leak?

	for (int i = pos; i < arr->length - 1; i++)
		arr->elems[i] = arr->elems[i + 1];
	arr->length--;
}



int getLengthDA(DynamicArray* arr)
{
	if (arr == NULL)
		return -1;

	return arr->length;
}

TElement getDA(DynamicArray* arr, int pos)
{
	return arr->elems[pos];
}

// ------------------------------------------------------------------------------------------------------------
// Tests

void testsDynamicArray()
{
	DynamicArray* da = createDA(2);
	if (da == NULL)
		assert(0);

	assert(da->capacity == 2);
	assert(da->length == 0);

	Offer* o1 = create_offer("house", "I.L. Caragiale 5/6", 42, 50000);
	addDA(da, o1);
	assert(da->length == 1);

	Offer* o2 = create_offer("penthouse", "I.L. Caragiale 6/6", 54, 16000);
	addDA(da, o2);
	assert(da->length == 2);

	// capacity must double
	Offer* o3 = create_offer("house", "I.L. Caragiale 8/6", 60, 58000);
	addDA(da, o3);
	assert(da->length == 3);
	assert(da->capacity == 4);

	// delete planet on position 0
	// first get the pointer to the planet, to still be able to access the pointed memory
	Offer* o = getDA(da, 0);
	deleteDA(da, 0);
	destroy_offer(o); // What is another option for implementing the function "delete" to make sure that the planet is destroyed inside?

	o = getDA(da, 0);
	assert(strcmp(get_address(o), "I.L. Caragiale 6/6") == 0);
	assert(da->length == 2);

	// destroy the dynamic array - this will also destroy the planets
	destroyDA(da);
}