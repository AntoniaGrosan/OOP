#pragma once
#include "Offer.h"
#include "DynamicArray.h"

typedef struct{
	DynamicArray* offers;
} OfferRepo;

/*
Creates an offer repository.
*/
OfferRepo* createRepo();

/*
Destroys a given offer repository. The memory is freed.
*/
void destroyRepo(OfferRepo* v);

/*
Finds the offer with the given address.
*/
Offer* findByAdr(OfferRepo* v, char* adr);

/*
Returns the offer on the given position in the offer vector.
Input:	v - the offer repository;
pos - integer, the position;
Output: the offer on the given potision, or NULL if there doesn't exist that position.
*/
Offer* getOfferOnPos(OfferRepo* v, int pos);

/*
Finds the position of an offer.
Input : v - the offer repository;
adr - the address of an offer;
Output: - -1 if the offer with the given address does not exist in the repo;
- the position;
*/
int findPosOfOffer(OfferRepo * v, char* adr);

/*
Adds an offer to the repository of offers.
Input:	
- v - pointer to the OfferRepo
- ofr - offer
Output: 
1 - if the offer was sucessfully added
0 - if the offer could not be added, as another offer with the same name already exists in the OfferRepo.
*/
int addOffer(OfferRepo * v, Offer* ofr);

/*
Deletes an offer from the repository of offers.
Input:
- v - pointer to the OfferRepo
- ofr - offer
Output:
1 - if the offer was sucessfully deleted
0 - if the offer could not be deleted, as the offer with the given name doesn't exist in the OfferRepo.
*/
int deleteOffer(OfferRepo* v, Offer* ofr);

/*
Updates the type of an offer from the repository of offers.
Input:
- v - pointer to the OfferRepo
- ofr - the offer which is going to be updated
- type - new type
Output:
1 - if the offer was sucessfully updated
0 - if the offer could not be updated, as the offer with the given address doesn't exist in the OfferRepo.
*/
int updateOffer(OfferRepo * v, Offer* ofr);


/*
Returns the length of the repository of offers
Input:
- v - pointer to the OfferRepo
Output:
- leng - the length of the repository
*/
int getLength(OfferRepo* v);

void testsRepo();