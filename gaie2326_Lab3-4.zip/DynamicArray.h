#pragma once
#pragma once
#include "Offer.h"
#define CAPACITY 50

typedef Offer* TElement;

typedef struct
{
	TElement* elems;
	int length;			// actual length of the array
	int capacity;		// maximum capacity of the array
} DynamicArray;

/*
Creates a dynamic array of generic elements, with a given capacity.
Input: - capacity - maximum capacity for the dynamic array
Output: - a pointer the the created dynamic array
*/
DynamicArray* createDA(int capacity);

/*
Destroys the dynamic array.
Input: - arr - the dynamic array to be destoyed
Output: - a pointer the the created dynamic array
*/
void destroyDA(DynamicArray* arr);

void setDA(DynamicArray* arr, int pos, Offer* newo);

/*
Adds a generic to the dynamic array.
Input: - arr - The dynamic array
	   - t - The element to be added
*/
void addDA(DynamicArray* arr, TElement t);

/*
Deletes an element from a given position in the dynamic array.
Input: - arr - the dynamic array
	   - pos - the position from which the element must be deleted. The position must be valid
*/
void deleteDA(DynamicArray* arr, int pos);


/*
Returns the length of the dynamic array.
Input: - arr - The dynamic array
*/
int getLengthDA(DynamicArray* arr);

/*
Returns the element on a given position.
Input: - arr - The dynamic array
	   - pos - The position - must be a valid position
	Output: - The element on the given position
*/
TElement getDA(DynamicArray* arr, int pos);

// Tests
void testsDynamicArray();
